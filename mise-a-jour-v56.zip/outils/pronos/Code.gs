/* KiosK — serveur des pronos entre amis (Google Apps Script, v56).
   Garde les joueurs et les pronos dans le Google Sheets auquel ce script est attaché (onglets « Joueurs » et « Pronos », créés tout seuls).
   Refuse un prono après le coup d'envoi (horaires lus sur le site publié, pas envoyés par le téléphone) et ne montre
   les pronos des autres qu'une fois le match commencé. Les points et le classement sont calculés par la page.
   v55 : groupes, pseudos et matchs toujours lus en texte (le Sheets changeait « 2026 » en nombre : inscription en double, « mauvais code »).
   v56 : avatar de chaque joueur (colonne E de Joueurs, « emoji|couleur ») et, pour les matchs pas commencés, qui a déjà pronostiqué (sans les scores).
   Mise en place : voir outils/dev/PRONOS.md. */
const SITE = 'https://zyavo.github.io/iPhone-Dock/';            // adresse du dock publié
const LIGUES = {'fra.1':'fra-1', '270559':'270559', 'uefa.champions':'uefa-champions'};   // id ESPN → fichier donnees/sport/<fichier>.json

function doPost(e){
  let r;
  try{ const q = JSON.parse((e && e.postData && e.postData.contents) || '{}'); const f = ACTIONS[q.action]; r = f ? f(q) : {err:'action'}; }
  catch(x){ r = {err:String(x && x.message || x)}; }
  return ContentService.createTextOutput(JSON.stringify(r)).setMimeType(ContentService.MimeType.JSON);
}
function doGet(){ return ContentService.createTextOutput(JSON.stringify({ok:true, service:'pronos'})).setMimeType(ContentService.MimeType.JSON); }

function feuille(nom, entetes, texte){
  const ss = SpreadsheetApp.getActive(); let f = ss.getSheetByName(nom);
  if (!f){ f = ss.insertSheet(nom); f.getRange(texte).setNumberFormat('@'); f.appendRow(entetes); f.setFrozenRows(1); }
  else if (f.getLastColumn() < entetes.length) f.getRange(1, 1, 1, entetes.length).setValues([entetes]);   // v56 : colonne ajoutée à un onglet existant
  return f;
}
const JOUEURS = () => feuille('Joueurs', ['groupe', 'pseudo', 'code (empreinte)', 'inscrit le', 'avatar'], 'A:C');
const PRONOS = () => feuille('Pronos', ['groupe', 'pseudo', 'match', 'ligue', 'dom', 'ext', 'le'], 'A:D');
const T = v => String(v);                                          // valeur de cellule en texte
const AV = s => { const m = /^([^|]{1,8})\|([0-7])$/.exec(String(s || '')); return m ? m[0] : ''; };   // avatar « emoji|n° de couleur »
const net = s => String(s || '').trim().slice(0, 20);
const grp = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
const empreinte = (g, p, pin) => Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, g + '|' + p.toLowerCase() + '|' + pin + '|mon-ecran'));

/* joueur reconnu (groupe + pseudo + code) ; null sinon */
function joueur(q){
  const g = grp(q.groupe), p = net(q.pseudo), pin = String(q.pin || '');
  if (!g || !p || !/^\d{4}$/.test(pin)) return null;
  const l = JOUEURS().getDataRange().getValues().slice(1), h = empreinte(g, p, pin);
  const i = l.findIndex(r => T(r[0]) === g && T(r[1]).toLowerCase() === p.toLowerCase()), x = l[i];
  return x && T(x[2]) === h ? {g, p:T(x[1]), ligne:i + 2} : null;
}

/* horaires des matchs : fichiers publiés par la tâche Sport (mémoire 10 min) */
function horaires(){
  const c = CacheService.getScriptCache(), m = c.get('horaires');
  if (m) return JSON.parse(m);
  const out = {};
  Object.values(LIGUES).forEach(f => { try{
    const j = JSON.parse(UrlFetchApp.fetch(SITE + 'donnees/sport/' + f + '.json', {muteHttpExceptions:true}).getContentText());
    (j.events || []).forEach(e => { out[e.id] = e.t; });
  }catch(x){} });
  try{ c.put('horaires', JSON.stringify(out), 600); }catch(x){}
  return out;
}

const ACTIONS = {
  inscrire(q){
    const g = grp(q.groupe), p = net(q.pseudo), pin = String(q.pin || '');
    if (!g || !p || !/^\d{4}$/.test(pin)) return {err:'champs'};
    const verrou = LockService.getScriptLock(); verrou.waitLock(10000);
    try{
      const f = JOUEURS(), l = f.getDataRange().getValues().slice(1);
      const i = l.findIndex(r => T(r[0]) === g && T(r[1]).toLowerCase() === p.toLowerCase()), x = l[i], av = AV(q.avatar);
      if (x){ if (T(x[2]) !== empreinte(g, p, pin)) return {err:'pris'}; if (av) f.getRange(i + 2, 5).setValue(av); return {ok:true}; }
      f.appendRow([g, p, empreinte(g, p, pin), new Date(), av]);
      return {ok:true};
    }finally{ verrou.releaseLock(); }
  },
  parier(q){
    const j = joueur(q); if (!j) return {err:'code'};
    const t = horaires()[String(q.match)];
    if (!t) return {err:'match'};
    if (Date.now() >= t) return {err:'ferme'};
    const h = Math.max(0, Math.min(200, parseInt(q.h, 10))), a = Math.max(0, Math.min(200, parseInt(q.a, 10)));
    if (isNaN(h) || isNaN(a)) return {err:'score'};
    const verrou = LockService.getScriptLock(); verrou.waitLock(10000);
    try{
      const f = PRONOS(), l = f.getDataRange().getValues();
      const i = l.findIndex((r, k) => k > 0 && T(r[0]) === j.g && T(r[1]) === j.p && T(r[2]) === String(q.match));
      const ligne = [j.g, j.p, String(q.match), String(q.ligue || ''), h, a, new Date()];
      if (i > 0) f.getRange(i + 1, 1, 1, ligne.length).setValues([ligne]); else f.appendRow(ligne);
      return {ok:true};
    }finally{ verrou.releaseLock(); }
  },
  avatar(q){
    const j = joueur(q); if (!j) return {err:'code'};
    const av = AV(q.avatar); if (!av) return {err:'avatar'};
    JOUEURS().getRange(j.ligne, 5).setValue(av);
    return {ok:true};
  },
  etat(q){
    const j = joueur(q); if (!j) return {err:'code'};
    const H = horaires(), now = Date.now(), pronos = {}, qui = {};
    PRONOS().getDataRange().getValues().slice(1).filter(r => T(r[0]) === j.g).forEach(r => {
      const id = T(r[2]), nom = T(r[1]), commence = H[id] && now >= H[id];
      if (!commence) (qui[id] || (qui[id] = [])).push(nom);    // v56 : qui a déjà pronostiqué (sans le score)
      if (nom !== j.p && !commence) return;                    // pronos des autres : seulement une fois le match commencé
      (pronos[id] || (pronos[id] = {}))[nom] = [r[4], r[5]];
    });
    const joueurs = [], avatars = {};
    JOUEURS().getDataRange().getValues().slice(1).filter(r => T(r[0]) === j.g).forEach(r => { joueurs.push(T(r[1])); if (AV(r[4])) avatars[T(r[1])] = T(r[4]); });
    return {joueurs, pronos, avatars, qui};
  }
};

/* À lancer une fois depuis l'éditeur (menu des fonctions › verifier › Exécuter) : demande les autorisations
   et vérifie que les horaires des matchs se lisent sur le site publié (journal : nombre de matchs trouvés). */
function verifier(){
  CacheService.getScriptCache().remove('horaires');
  const n = Object.keys(horaires()).length;
  Logger.log(n ? n + ' matchs trouvés sur ' + SITE : 'Aucun match lu : vérifier SITE (' + SITE + ')');
  JOUEURS(); PRONOS();
}
