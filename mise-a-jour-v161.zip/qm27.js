// mon-ecran-version: 5ddfd9bc
/* QM27 (v83, lot 2 : v84, lot 3 : v85) — moteur du jeu, sans affichage : window.QM.
   Monde (ligues, clubs, joueurs), calendrier de la saison, simulation des matchs pas à pas (15 s de jeu par pas),
   classements, fin de saison, sauvegarde. Le même code tourne dans la page et dans outils/dev/qm27-essai.mjs.
   Hasard à graine : un match = une graine + deux compositions + deux tactiques ; mêmes entrées, même match. */
(function(root){
'use strict';
const D = root.QMD;
const EQ = D.EQ;
const VERSION = 13;   // v160 : note recalculée sur le moteur ; v155 : vingt rôles à effets propres, synergies, vif d'or à 80 points ; v152 : maîtrise tactique par élément, trois plans de jeu, managers de l'ordinateur ; v113 : droits TV relevés, plafonds de masse salariale recalculés ;   // v94 : potentiels plafonnés (fin de l'inflation des notes), historique de carrière (j.carr) ; v7   // v91 : tournoi pendant le championnat (j.inter), programme d'entraînement, profil du manager, records (qm27-bureau.js) ; v89 : manies des joueurs, dispositions avec et sans le souafle, tireur de penalty ; v90 : vestiaire et mercato (qm27-vestiaire.js)   // v84 : contrats, staff, finances, entraînement (qm27-club.js) ; v85 : stade, centre de formation, carrière, sélection (qm27-carriere.js) ; une sauvegarde plus ancienne est complétée au chargement
const C = () => root.QMC;   // gestion du club (qm27-club.js), facultative pour le moteur

/* ---------- Hasard à graine (mulberry32) ---------- */
function hasard(graine){
  let a = (graine >>> 0) || 1;
  const r = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  r.ent = (min, max) => min + Math.floor(r() * (max - min + 1));
  r.choix = L => L[Math.floor(r() * L.length)];
  r.gauss = () => { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  r.pondere = paires => { const tot = paires.reduce((s, p) => s + p[1], 0); let x = r() * tot; for (const [v, w] of paires){ x -= w; if (x < 0) return v; } return paires[paires.length - 1][0]; };
  r.etat = () => a; r.reprendre = e => { a = e >>> 0; };
  return r;
}
const melange = (...n) => { let h = 2166136261; for (const x of n){ const s = String(x); for (let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } } return h >>> 0; };
const borne = (x, a, b) => Math.max(a, Math.min(b, x));

/* ---------- Attributs et notes ---------- */
const ATT = D.ATTRS.map(a => a[0]);
const IDX = Object.fromEntries(ATT.map((k, i) => [k, i]));
const GIDX = Object.fromEntries(D.GARDIEN.map((g, i) => [g[0], i]));
const POIDS = {};
['P', 'B', 'A', 'G'].forEach((p, pi) => { POIDS[p] = D.ATTRS.map(a => a[3][pi] === '●' ? 3 : a[3][pi] === '○' ? 1 : 0); });
const at = (j, k) => j.a[IDX[k]];
const ga = (j, k) => j.g[GIDX[k]];
/* note d'un joueur à un poste, sur 20. v160 : poids mesurés sur le moteur (QMD.NOTE.poids : effet réel de chaque attribut en match, rôles mélangés),
   puis recalée (QMD.NOTE.cal : a + b × moyenne pondérée) pour garder l'échelle d'avant (moyenne et dispersion des notes d'un monde neuf, donc valeurs et salaires) */
const POIDS_NOTE = {}, POIDS_NOTE_G = {};
['P', 'B', 'A', 'G'].forEach(p => { const W = D.NOTE && D.NOTE.poids[p]; POIDS_NOTE[p] = W ? ATT.map(k => W[k] || 0) : POIDS[p]; POIDS_NOTE_G[p] = D.GARDIEN.map(g => W ? W['g:' + g[0]] || 0 : 3); });
function noteBrute(j, poste){
  const w = POIDS_NOTE[poste]; let s = 0, n = 0;
  for (let i = 0; i < w.length; i++){ s += j.a[i] * w[i]; n += w[i]; }
  if (poste === 'G' && j.g){ const wg = POIDS_NOTE_G.G; for (let i = 0; i < j.g.length; i++){ s += j.g[i] * wg[i]; n += wg[i]; } }
  return s / n;
}
/* part de chaque attribut dans la note d'un poste (0 à 1) : {clé: part}, clés du gardien préfixées « g: » */
function partNote(poste){ const w = POIDS_NOTE[poste], wg = poste === 'G' ? POIDS_NOTE_G.G : [], t = w.reduce((a, b) => a + b, 0) + wg.reduce((a, b) => a + b, 0), R = {};
  ATT.forEach((k, i) => { if (w[i]) R[k] = w[i] / t; }); D.GARDIEN.forEach((g, i) => { if (wg[i]) R['g:' + g[0]] = wg[i] / t; }); return R; }
function note20(j, poste){ const c = D.NOTE && D.NOTE.cal[poste], x = noteBrute(j, poste); return c ? c[0] + c[1] * x : x; }
const note = (j, poste) => Math.round(note20(j, poste || j.poste) * 5);   // affichage sur 100
const meilleurPoste = j => ['P', 'B', 'A', 'G'].reduce((b, p) => note20(j, p) > note20(j, b) ? p : b, j.poste);

/* ---------- Création du monde ---------- */
/* v94 : marge de progression (potentiel − niveau actuel, sur 20). Avant v94 : (22 − âge) × 0,8 + |gauss| × 1,8 à tout âge,
   d'où une inflation des notes de saison en saison (le meilleur joueur passait de 74 à 92 en six saisons). */
const margePot = (age, r) => age <= 21 ? (22 - age) * 0.45 + Math.abs(r.gauss()) * 1.0 : age <= 24 ? 0.5 + Math.abs(r.gauss()) * 0.8 : age <= 28 ? Math.abs(r.gauss()) * 0.5 : Math.abs(r.gauss()) * 0.2;
const margeMax = age => age <= 21 ? (22 - age) * 0.45 + 2.0 : age <= 24 ? 2.1 : age <= 28 ? 1.0 : 0.4;
function creerJoueur(r, nat, poste, niveau, age, id){
  const N = D.NOMS[nat];
  const w = POIDS[poste];
  const a = ATT.map((k, i) => {
    const base = w[i] === 3 ? niveau + 0.6 : w[i] === 1 ? niveau - 1.6 : niveau - 4.5;
    return Math.round(borne(base + r.gauss() * 1.7, 1, 20));
  });
  const g = D.GARDIEN.map(() => Math.round(borne((poste === 'G' ? niveau + 0.8 : niveau - 7) + r.gauss() * 1.6, 1, 20)));
  const ca = note20({a, g}, poste);
  const pot = Math.round(borne(ca + margePot(age, r), ca, 19.5) * 10) / 10;
  const c = () => r.ent(4, 18);
  return {id, p:r.choix(N.p), n:r.choix(N.n), nat, age, poste, a, g,
          cache:{pot, reg:c(), pro:c(), amb:c(), frag:c(), gm:c(), ada:c(), loy:c()},
          forme:6, fat:0, moral:60, bless:null, club:null, num:0,
          saison:{m:0, b:0, v:0, cog:0, arr:0, notes:0}};
}
/* v113 : âges de départ proches de l'équilibre (entrées à 17-21 ans, retraites étalées de 31 à 37 ans) : sans la vague de retraites puis de jeunes vers la 8e saison */
const AGES_DEPART = [[17, 2], [18, 4], [19, 5], [20, 6], [21, 7], [22, 7], [23, 7], [24, 7], [25, 7], [26, 7], [27, 7], [28, 7], [29, 6], [30, 6], [31, 5], [32, 4], [33, 3], [34, 2], [35, 1]];
const AGE = r => r.pondere(AGES_DEPART);
const AGE_JEUNE = r => r.pondere([[17, 3], [18, 4], [19, 4], [20, 3], [21, 2]]);
const RETRAITE = {31:0.03, 32:0.07, 33:0.15, 34:0.3, 35:0.5, 36:0.8};   // probabilité par été ; 37 ans et plus : toujours
const EFFECTIF = ['P', 'P', 'P', 'B', 'B', 'A', 'G', 'P', 'P', 'P', 'B', 'B', 'A', 'G', 'P', 'B'];   // 16 joueurs : 7 titulaires + 9

function nouveauMonde(graine){
  graine = (graine >>> 0) || (Date.now() >>> 0);
  const r = hasard(graine);
  const M = {v:VERSION, graine, saison:2026, semaine:0, joueurs:{}, clubs:{}, ligues:{}, calendrier:[], sixn:{tab:{}, matchs:[]},
             manager:null, boite:[], histo:[], prochainId:1, dernierMatch:null, emplacement:null};
  for (const L of D.LIGUES) M.ligues[L.id] = {id:L.id, nom:L.nom, court:L.court, clubs:[]};
  for (const def of D.CLUBS) if (M.ligues[def[4]]) creerClub(M, r, def);   // v106 : les clubs de réserve (future D2) restent hors du jeu
  M.calendrier = calendrierSaison(M, r);
  remettreClassements(M);
  nommer(M);   // v114 : avant initMonde, qui peut citer les clubs
  if (C()) C().initMonde(M, r);
  return M;
}
/* un club et son effectif de 16 joueurs (v106 : aussi pour les nouveaux clubs d'une partie en cours) */
function creerClub(M, r, [id, nom, ville, nat, ligue, rep, c1, c2, stade]){
  const club = {id, nom, ville, nat, ligue, rep, couleurs:[c1, c2], stade, effectif:[], compo:null, tactique:tactiqueIA(r), balai:balaiPour(rep),
                sigle:sigleLibre(M, nom, ville), budget:Math.round(rep * rep * 900 / 1000) * 1000};
  M.clubs[id] = club; M.ligues[ligue].clubs.push(id);
  const niveau = EQ.niveauMin + (rep - 40) / 45 * (EQ.niveauMax - EQ.niveauMin);
  EFFECTIF.forEach((poste, i) => {
    const nat2 = r.pondere(D.ORIGINES[nat]);
    const titulaire = i < 7;
    const lvl = niveau + (titulaire ? 0.6 : -0.9) + r.gauss() * 0.9;
    const j = creerJoueur(r, nat2, poste, lvl, AGE(r), 'j' + (M.prochainId++));
    j.club = id; j.num = i + 1; M.joueurs[j.id] = j; club.effectif.push(j.id);
  });
  club.compo = compoAuto(M, id);
  return club;
}
/* v106 : Berlin et Bergen, Bari et Barcelona… deux clubs ne partagent pas le même sigle */
function sigleLibre(M, nom, ville){
  const pris = new Set(Object.values(M.clubs).map(c => c.sigle)), v = ville.normalize('NFD').replace(/[^\w]/g, '').toUpperCase();
  for (const s of [v.slice(0, 3), v.slice(0, 2) + v.slice(-1), v[0] + v.slice(2, 4), v[0] + v[1] + v[3]]) if (s.length === 3 && !pris.has(s)) return s;
  return v.slice(0, 3);
}
function sigle(nom, ville){ const v = ville.normalize('NFD').replace(/[^\w]/g, '').toUpperCase(); return v.slice(0, 3); }
function balaiPour(rep){ return rep >= 80 ? 'aquilon' : rep >= 70 ? 'strix' : rep >= 60 ? 'sirocco' : rep >= 52 ? 'mistral' : rep >= 46 ? 'albatros' : 'zephyr'; }
function tactiqueIA(r){
  return {rythme:r.ent(1, 3), risque:r.ent(1, 3), agressivite:r.ent(1, 3), passes:r.choix(['court', 'long']), sans:r.choix(['pressing', 'zone', 'zone', 'repli']),
          avec:r.choix(['triangle', 'triangle', 'ligne', 'pointe']), batAvec:r.choix(['escorte', 'devant']), batSans:r.choix(['protection', 'harcelement']), zone:r.choix(['axe', 'couloirs', 'loin']),
          cible:r.choix(['poursuiveur', 'poursuiveur', 'attrapeur', 'gardien']), attrapeur:'gagnant', gardien:r.choix(['anneaux', 'sortie'])};
}
const TACTIQUE_DEFAUT = () => ({rythme:2, risque:2, agressivite:2, passes:'court', sans:'zone', avec:'triangle', batAvec:'escorte', batSans:'protection', zone:'axe', cible:'poursuiveur', attrapeur:'gagnant', gardien:'anneaux', vifMode:'chasse'});
/* v89 : dispositions avec et sans le souafle (une tactique d'avant v89 n'a que « pressing ») */
const sansDe = T => T.sans || (T.pressing === 'haut' ? 'pressing' : 'repli');
const CONTRE = {pressing:'axe', zone:'couloirs', repli:'loin'};   // la zone d'attaque qui fait mal à chaque défense
function completerTactique(T){ if (!T) return T; if (!T.sans) T.sans = sansDe(T); delete T.pressing; T.avec = T.avec || 'triangle'; T.batAvec = T.batAvec || 'escorte'; T.batSans = T.batSans || 'protection'; T.zone = T.zone || 'axe'; T.vifMode = T.vifMode || 'chasse'; return T; }
/* v89 : manies (traits) d'un joueur, tirées une fois pour toutes selon ses attributs */
function maniesPour(j){
  const r = hasard(melange('manies', j.id)), L = D.MANIES.filter(m => m[2].includes(j.poste) || (m[2] === 'PBAG'));
  const n = r() < 0.12 ? 2 : r() < 0.5 ? 1 : 0, pris = [];
  for (let k = 0; k < n; k++){ const c = L.filter(m => !pris.includes(m[0])).map(m => [m[0], Math.pow(m[4].reduce((s, a) => s + at(j, a), 0) / m[4].length, 2.2) * (m[2] === 'PBAG' ? 0.35 : 1)]); if (c.length) pris.push(r.pondere(c)); }
  return pris;
}
const manies = j => j ? (j.m || (j.m = maniesPour(j))) : [];
const aManie = (j, k) => !!j && manies(j).includes(k);

/* ---------- Compositions ---------- */
const dispo = (M, id) => { const j = M.joueurs[id]; return j && !j.bless && !j.inter && !j.susp; };   // v158 : suspendu   // v91 : j.inter = convoqué en sélection cette semaine
const NB_BANC = () => D.EQ.banc || 5;   // v86 : 5 remplaçants
function compoAuto(M, clubId){
  const club = M.clubs[clubId], pris = new Set();
  let ids = club.effectif.filter(id => dispo(M, id));
  if (ids.length < 9) ids = club.effectif.filter(id => M.joueurs[id] && !M.joueurs[id].bless && !M.joueurs[id].susp);   // v91 : trop d'internationaux absents, on rappelle du monde
  const pick = (poste, n) => {
    const L = ids.filter(id => !pris.has(id)).map(id => { const j = M.joueurs[id]; return [id, note20(j, poste) - Math.max(0, j.fat - 30) / 14 + (j.poste === poste ? 0.4 : 0)]; })   // v96 : l'ordinateur fait tourner les joueurs fatigués
      .sort((a, b) => b[1] - a[1]).slice(0, n).map(x => x[0]);
    L.forEach(id => pris.add(id)); return L;
  };
  const c = {A:pick('A', 1), G:pick('G', 1), B:pick('B', 2), P:pick('P', 3)};
  const banc = [...pick('P', 2), ...pick('B', 1), ...pick('A', 1), ...pick('G', 1), ...pick('P', 2)];
  c.banc = banc.slice(0, NB_BANC());
  rolesAuto(M, c, false, root.QMG && root.QMG.poidsStyle ? root.QMG.poidsStyle(M, clubId) : null);   // v157 : rôles selon le style de l'entraîneur
  return c;
}
/* v84 : rôles individuels (gardés par joueur) et capitaine, choisis d'après les attributs quand ils manquent */
const ROLE_DEFAUT = {P:'polyvalent', B:'escorteur', A:'chasseur', G:'ligne'};   // v155 : rôle par défaut de chaque poste
const roleValide = (poste, r) => (D.ROLES[poste] || []).some(x => x[0] === r);
/* v153 : note d'un joueur dans un rôle (sur 20 : moyenne pondérée des attributs du rôle), exécution (0,85 à 1,1 : le rôle colle-t-il à son profil ?
   hors de son poste : 0,8), badge indicatif (bronze, argent, or) */
/* valeur typique d'un attribut à un poste (les joueurs sont tirés autour de 12 pour un attribut clé ●, 9,7 pour un secondaire ○, 6,7 sinon) */
const TYPV = {'●':12, '○':9.7, ' ':6.7}, TYPC = {};
function typique(poste, k){ const T = TYPC[poste] || (TYPC[poste] = {}); if (T[k] != null) return T[k]; if (k.startsWith('g:')) return T[k] = poste === 'G' ? 12 : 6;
  const a = D.ATTRS.find(x => x[0] === k), i = 'PBAG'.indexOf(poste); return T[k] = a ? TYPV[a[3][i]] ?? 9.7 : 9.7; }
function refRole(poste, role){ const R = (D.ROLE_DEF[poste] || {})[role]; if (!R) return 12; let s = 0, n = 0; for (const k in R.at){ s += typique(poste, k) * R.at[k]; n += R.at[k]; } return s / n; }
const valA = (j, k) => k.startsWith('g:') ? (j.g ? ga(j, k.slice(2)) : 6) : at(j, k);
function scoreRole(j, poste, role){ const R = (D.ROLE_DEF[poste] || {})[role]; if (!j) return 0; if (!R) return note20(j, poste); let s = 0, n = 0; for (const k in R.at){ s += valA(j, k) * R.at[k]; n += R.at[k]; } return s / n; }
function execRole(j, poste, role){ if (!j) return 1; if (j.poste !== poste) return 0.8; return borne(1 + (scoreRole(j, poste, role) - note20(j, poste)) * 0.05, 0.85, 1.1); }
const qualiteRole = (j, poste, role) => borne(0.5 + (scoreRole(j, poste, role) - refRole(poste, role)) / 8, 0, 1.6) * execRole(j, poste, role);   // 0,5 pour un joueur typique du poste
function badge(j, poste, role){ poste = poste || (j && j.poste); if (!j || j.poste !== poste) return null; if (execRole(j, poste, role) < 0.97) return null; const s = scoreRole(j, poste, role) - refRole(poste, role); return D.BADGES.find(b => s >= b[2]) || null; }   // écart à la valeur typique du rôle, pour un rôle qui lui va (au moins son niveau au poste, à 0,6 point près)
function roleAuto(j, poste){ return (D.ROLES[poste] || []).map(x => [x[0], qualiteRole(j, poste, x[0])]).sort((a, b) => b[1] - a[1])[0][0]; }
/* synergies d'une équipe (composition + rôles) : [{…synergie, a, b, ok}] ; ok = condition remplie */
function synergiesDe(M, e){
  const L = [], R = e.roles || {}, qui = (p, r) => (e[p] || []).find(id => R[id] === r);
  for (const S of D.SYNERGIES){ const a = qui(S.r[0][0], S.r[0][1]), b = qui(S.r[1][0], S.r[1][1]); if (!a || !b || a === b) continue;
    let ok = true; if (S.cond){ const j = M.joueurs[S.cond[0] === 0 ? a : b]; ok = !!j && valA(j, S.cond[1]) >= S.cond[2]; }
    L.push({...S, a, b, ok}); }
  return L;
}
function antiSynergiesDe(M, e){
  const R = e.roles || {}, n = (p, r) => (e[p] || []).filter(id => R[id] === r).length, L = [];
  if (n('P', 'finisseur') >= 2) L.push(D.ANTI_SYNERGIES[0]); if (n('B', 'briseur') >= 2) L.push(D.ANTI_SYNERGIES[1]);
  if (n('G', 'libero') && !n('B', 'gardeAnneaux')) L.push(D.ANTI_SYNERGIES[2]);
  return L;
}
/* rôles de l'ordinateur (ou des places sans rôle) : la meilleure combinaison poste par poste (gardien, attrapeur, batteurs, poursuiveurs) :
   leviers de l'équipe pondérés (POIDS_LEV, rendements décroissants) + 0,25 par synergie − 0,35 par anti-synergie */
const POIDS_LEV = {constr:1, finit:1, garde:0.6, recup:0.8, rempart:1, bouclier:0.5, marteau:0.45, ange:0.35, vif:0.9, gene:0.5, contre:0.55};   // v155 : importance de chaque levier pour choisir les rôles
function optimiserRoles(M, c, fixes, poids){
  const roles = {...fixes}, eq = () => ({...c, roles});
  const choix = (p, ids) => ids.map(id => roles[id] && roleValide(p, roles[id]) && fixes[id] ? [roles[id]] : (D.ROLES[p] || []).map(x => x[0]));
  /* valeur d'une répartition : leviers de l'équipe (rendements décroissants, poids de chaque levier dans le jeu) + synergies − anti-synergies */
  const QC = {}, qual = (id, p, r) => { const k = id + r; return QC[k] ?? (QC[k] = qualiteRole(M.joueurs[id], p, r)); };
  const valeur = () => { const parts = {};
    for (const p of ['P', 'B', 'A', 'G']) for (const id of c[p] || []){ const r = roles[id], R = r && (D.ROLE_DEF[p] || {})[r]; if (!R || !M.joueurs[id]) continue; const q = qual(id, p, r); for (const l in R.lev) (parts[l] = parts[l] || []).push(R.lev[l] * q); }
    let v = 0; for (const l in parts){ const L = parts[l].sort((a, b) => b - a); v += (POIDS_LEV[l] || 0.5) * ((poids || {})[l] || 1) * L.reduce((t, x, i) => t + x * (EQ.lev.decr[i] ?? 0.1), 0); }
    return v + synergiesDe(M, eq()).filter(x => x.ok).length * 0.25 - antiSynergiesDe(M, eq()).length * 0.35; };
  for (const p of ['G', 'A', 'B', 'P']){
    const ids = (c[p] || []).filter(id => M.joueurs[id]), C = choix(p, ids); if (!ids.length) continue;
    let best = null, bv = -1e9;
    const essai = (i, acc) => {
      if (i === ids.length){ ids.forEach((id, k) => roles[id] = acc[k]);
        const v = valeur();
        if (v > bv){ bv = v; best = acc.slice(); } return; }
      for (const r of C[i]) essai(i + 1, [...acc, r]);
    };
    essai(0, []); ids.forEach((id, k) => roles[id] = best[k]);
  }
  return roles;
}
const CACHE_ROLES = new Map();   // composition déjà optimisée (cette saison) → rôles
function rolesAuto(M, c, garder, poids){
  const ancien = garder ? (c.roles || {}) : {}, fixes = {};
  for (const p of ['P', 'B', 'A', 'G']) for (const id of c[p]) if (roleValide(p, ancien[id])) fixes[id] = ancien[id];
  const cle = M.graine + ':' + M.saison + ':' + JSON.stringify(poids || 0) + ['P', 'B', 'A', 'G'].map(p => c[p].join(',')).join('|') + ':' + Object.entries(fixes).join(';');
  if (!CACHE_ROLES.has(cle)){ if (CACHE_ROLES.size > 3000) CACHE_ROLES.clear(); CACHE_ROLES.set(cle, optimiserRoles(M, c, fixes, poids)); }
  c.roles = {...CACHE_ROLES.get(cle)};
  const tit = titulaires(c).filter(id => M.joueurs[id]);
  if (!garder || !tit.includes(c.cap)) c.cap = tit.slice().sort((a, b) => { const x = M.joueurs[a], y = M.joueurs[b]; return (at(y, 'det') + at(y, 'con') + y.age / 4) - (at(x, 'det') + at(x, 'con') + x.age / 4); })[0] || null;
  const P = c.P.filter(id => M.joueurs[id]), tp = j => at(j, 'tir') * 2 + at(j, 'pre') + at(j, 'san');   // v89 : tireur de penalty
  if (!garder || !P.includes(c.pen)) c.pen = P.slice().sort((a, b) => tp(M.joueurs[b]) - tp(M.joueurs[a]))[0] || null;
  return c;
}
const titulaires = c => [...c.P, ...c.B, ...c.A, ...c.G];
/* composition du joueur vérifiée avant un match : un titulaire blessé est remplacé (renvoie la liste des changements) */
function verifierCompo(M, clubId){
  const club = M.clubs[clubId];
  if (!club.compo){ club.compo = compoAuto(M, clubId); return []; }
  const c = club.compo, faits = [], dans = id => club.effectif.includes(id), utilises = new Set();
  for (const poste of ['A', 'G', 'B', 'P']) for (const id of c[poste]) if (dans(id) && dispo(M, id)) utilises.add(id);
  for (const poste of ['A', 'G', 'B', 'P']){
    c[poste] = c[poste].map(id => {
      if (dans(id) && dispo(M, id)) return id;
      const v = x => note20(M.joueurs[x], poste) + (c.banc.includes(x) ? 0.3 : 0);
      const n = club.effectif.filter(x => dispo(M, x) && !utilises.has(x)).sort((a, b) => v(b) - v(a))[0];
      if (!n) return id;
      utilises.add(n); faits.push([id, n]); return n;
    });
  }
  const tit = new Set(titulaires(c));
  const banc = c.banc.filter(id => id && dans(id) && !tit.has(id) && dispo(M, id));
  for (const id of club.effectif) if (banc.length < NB_BANC() && !tit.has(id) && !banc.includes(id) && dispo(M, id)) banc.push(id);
  c.banc = banc.slice(0, NB_BANC());
  rolesAuto(M, c, true);
  return faits;
}

/* ---------- Calendrier ---------- */
function roundRobin(ids, r){
  const L = ids.slice(); for (let i = L.length - 1; i > 0; i--){ const k = Math.floor(r() * (i + 1)); [L[i], L[k]] = [L[k], L[i]]; }
  const n = L.length, tours = [];
  for (let t = 0; t < n - 1; t++){
    const m = [];
    for (let i = 0; i < n / 2; i++){ const a = L[i], b = L[n - 1 - i]; m.push(t % 2 === 0 ? [a, b] : [b, a]); }
    tours.push(m); L.splice(1, 0, L.pop());
  }
  return [...tours, ...tours.map(t => t.map(([a, b]) => [b, a]))];
}
const jour = (an, mois, j) => Date.UTC(an, mois, j);
function calendrierSaison(M, r){
  const an = M.saison, S = [];
  const tours = {}; for (const L of Object.values(M.ligues)) tours[L.id] = roundRobin(L.clubs, r);
  /* samedis : journées 1-15 de septembre à décembre, trêve, 16-20 en janvier, puis 21-30 ; v91 : le Tournoi des Six Emblèmes se joue PENDANT
     les journées 21 à 26 (tours 1-2, semaine de repos, tours 3-5) : les internationaux convoqués manquent le match de leur club (j.inter) */
  const samedi = (mois) => { let x = new Date(jour(an, mois, 1)); while (x.getUTCDay() !== 6) x = new Date(x.getTime() + 864e5); return x; };
  let d = samedi(7);                                   // v84 : préparation en août (mercato d'été ouvert)
  const sept = samedi(8);
  for (let k = 1; d < sept; k++){ S.push({date:d.getTime(), type:'prepa', semaine:k, matchs:[]}); d = new Date(d.getTime() + 7 * 864e5); }
  d = sept;
  const plus = n => { d = new Date(d.getTime() + n * 7 * 864e5); };
  let jl = 0;
  const ligue = () => { const m = []; for (const L of Object.values(M.ligues)) for (const [a, b] of tours[L.id][jl]) m.push({id:`${an}-${L.id}-${jl + 1}-${a}`, ligue:L.id, dom:a, ext:b, res:null});
    S.push({date:d.getTime(), type:'ligue', journee:jl + 1, matchs:m}); jl++; plus(1); };
  /* v106 : plus de Tournoi des Six Emblèmes pendant le championnat. Trois trêves internationales (après les journées 4, 9 et 23 :
     octobre, novembre, mars) où chaque sélection joue un amical ; l'été, une saison sur deux, la Ligue des nations (8 semaines),
     sinon une quatrième trêve en juin. La finale des Anneaux a sa semaine juste après la 30e journée. */
  const N = root.QMN, treve = k => { if (!N) return; S.push({date:d.getTime(), type:'sixn', comp:'ami', fen:k, matchs:N.amicaux(M, an, k)}); plus(1); };
  for (let i = 0; i < 15; i++){ ligue(); if (jl === 4) treve(1); if (jl === 9) treve(2); }
  plus(2);                                      // trêve des fêtes
  for (let i = 0; i < 15; i++){ ligue(); if (jl === 23) treve(3); }
  S.push({date:d.getTime(), type:'europe', matchs:[]}); plus(1);   // finale de la Ligue des Anneaux (qm27-europe.js)
  if (N && N.aLdn(an)){ plus(1); for (const x of N.semainesLdn(M, an)){ S.push({date:d.getTime(), type:'sixn', comp:'ldn', etape:x.etape, matchs:x.matchs}); plus(1); } }
  else { plus(3); treve(4); }
  S.push({date:d.getTime(), type:'bilan', matchs:[]});
  return S;
}

/* ---------- Classements ---------- */
const ligneVide = id => ({id, j:0, g:0, n:0, p:0, pm:0, pe:0, vifs:0, pts:0, forme:[]});
function remettreClassements(M){
  M.tables = {};
  for (const L of Object.values(M.ligues)){ M.tables[L.id] = {}; for (const id of L.clubs) M.tables[L.id][id] = ligneVide(id); }
  M.tables.sixn = {}; for (const n of (M.calendrier.some(s => s.tour) ? D.SIX_NATIONS : D.SELECTIONS)) M.tables.sixn[n] = ligneVide(n);   // v106 : bilan de toutes les sélections
  M.statsC = {}; M.statsDepuis = 0;   // v102 : stats d'équipes de la saison (statsDepuis : journée où le suivi a commencé)
}
function compter(M, m){
  const T = M.tables[m.ligue]; if (!T){ if (root.QME) root.QME.resultat(M, m); return; }   // v104 : Ligue des Anneaux
  const a = T[m.dom], b = T[m.ext], [sa, sb] = m.res.score;
  for (const [x, s1, s2, cote] of [[a, sa, sb, 0], [b, sb, sa, 1]]){
    x.j++; x.pm += s1; x.pe += s2; if (m.res.vif === cote) x.vifs++;
    const r = s1 > s2 ? 'g' : s1 < s2 ? 'p' : 'n'; x[r]++; x.pts += r === 'g' ? EQ.points.victoire : r === 'n' ? EQ.points.nul : 0;
    x.forme.push(r.toUpperCase().replace('G', 'V').replace('P', 'D')); if (x.forme.length > 5) x.forme.shift();
  }
}
function classement(M, ligue){
  return Object.values(M.tables[ligue]).sort((a, b) => b.pts - a.pts || (b.pm - b.pe) - (a.pm - a.pe) || b.pm - a.pm || b.vifs - a.vifs || String(a.id).localeCompare(b.id));
}

/* ---------- Équipes pour un match ---------- */
function equipeClub(M, clubId){
  const club = M.clubs[clubId]; if (!club.compo) club.compo = compoAuto(M, clubId);
  const c = club.compo; if (!c.roles) rolesAuto(M, c, true);
  return {id:clubId, nom:club.nom, sigle:club.sigle, couleurs:club.couleurs, tactique:completerTactique({...club.tactique}), balai:root.QMB ? root.QMB.balaiDe(club) : D.BALAIS.find(b => b.id === club.balai) || D.BALAIS[0],
          P:c.P.slice(), B:c.B.slice(), A:c.A.slice(), G:c.G.slice(), banc:c.banc.slice(), rep:club.rep, roles:{...c.roles}, cap:c.cap, pen:c.pen,
          cohesion:club.cohesion ?? 70, usure:club.usure ?? 100, ...(root.QMG && root.QMG.bonusMatch ? root.QMG.bonusMatch(M, club) : {})};   // v127 : maîtrise tactique, mise en place
}
function selection(M, nat){
  const L = Object.values(M.joueurs).filter(j => j.nat === nat && !j.bless && j.club && !j.acad), pris = new Set();   // v85 : ni agents libres ni jeunes du centre
  const pick = (poste, n) => { const s = L.filter(j => !pris.has(j.id)).sort((a, b) => note20(b, poste) - note20(a, poste)).slice(0, n).map(j => j.id); s.forEach(x => pris.add(x)); return s; };
  const e = {id:nat, nom:D.NATIONS[nat].nom, sigle:D.NATIONS[nat].court, couleurs:['#33415c', '#e0e1dd'], tactique:TACTIQUE_DEFAUT(), balai:D.BALAIS[4],
             A:pick('A', 1), G:pick('G', 1), B:pick('B', 2), P:pick('P', 3), rep:70};
  e.banc = [...pick('P', 2), ...pick('B', 1), ...pick('A', 1), ...pick('G', 1), ...pick('P', 2)].slice(0, NB_BANC());
  rolesAuto(M, e); e.cohesion = 60; e.usure = 100;
  return e;
}

/* ---------- Match ---------- */
function meteoPour(r, date){ const mois = new Date(date).getUTCMonth(); return r.pondere(Object.entries(D.METEO_MOIS(mois))); }
function texte(rt, cle, v){
  const L = D.TEXTES[cle]; if (!L) return '';
  return rt.choix(L).replace(/\{(\w)\}/g, (_, k) => v[k] ?? '');
}
/* Crée un match : M (pour les joueurs), deux équipes, graine, options {date, domicile:true, texte:true} */
function creerMatch(M, e0, e1, graine, opts = {}){
  for (const e of [e0, e1]) completerTactique(e.tactique);
  const r = hasard(graine), rt = hasard(melange(graine, 'texte')), rX = hasard(melange(graine, 'surprise'));   // v153 : tirage à part pour la forme des joueurs
  const meteo = opts.meteo || meteoPour(r, opts.date || Date.now());
  const X = {graine, e:[e0, e1], score:[0, 0], t:0, pas:0, fini:false, vif:-1, meteo, poss:r() < 0.5 ? 0 : 1, ev:[], evNouv:[],
             stats:[{tirs:0, buts:0, arrets:0, cog:0, fautes:0, pen:0}, {tirs:0, buts:0, arrets:0, cog:0, fautes:0, pen:0}],
             vifApp:(EQ.vifApparitionMin + r() * (EQ.vifApparitionMax - EQ.vifApparitionMin) + (meteo === 'brouillard' ? 6 : 0)) * 60,
             vifVu:false, vifCache:0, vifDepuis:0, sonne:[0, 0], gSonne:[0, 0], tm:[2, 2], rempl:[3, 3], moral:[0, 0],
             perf:{}, fat:{}, bless:[], jour:[1 + r.gauss() * EQ.jour, 1 + r.gauss() * EQ.jour], domicile:opts.domicile !== false, avecTexte:opts.texte !== false, r, rt, M};
  X.e.forEach((e, k) => { if (e.cap) X.moral[k] = 0.5; if (e.moralDom && k === 0 && X.domicile) X.moral[k] += e.moralDom; if (e.moralBase) X.moral[k] = borne(X.moral[k] + e.moralBase, -3, 3); });
  for (const e of X.e) for (const id of [...titulaires(e), ...(e.banc || [])]){ const j = M.joueurs[id]; X.fat[id] = j ? j.fat : 0; X.perf[id] = {eq:X.e.indexOf(e), b:0, t:0, arr:0, cog:0, enc:0, vif:0, rate:0, m:titulaires(e).includes(id) ? 1 : 0, tit:titulaires(e).includes(id) ? 1 : 0, in:0}; }   // v102 : titulaire, minute d'entrée
  /* v153 : part d'inconnu. Forme du jour de chaque joueur (écart type de 1,5 % pour le plus régulier à 7 % pour le moins régulier), matchs importants
     (opts.enjeu), Adaptabilité à la météo (moyenne des titulaires : 1 = effet normal), sursaut de l'outsider face à un club bien plus réputé */
  const SP = EQ.surprise; X.fj = {}; X.enjeu = !!opts.enjeu;
  for (const e of X.e) for (const id of [...titulaires(e), ...(e.banc || [])]){ const j = M.joueurs[id]; if (!j) continue; const rg = (j.cache && j.cache.reg) || 11;
    X.fj[id] = borne(1 + rX.gauss() * (SP.regMin + (18 - rg) / 14 * (SP.regMax - SP.regMin)), 0.8, 1.2); }
  X.ada = X.e.map(e => { const L = titulaires(e).map(id => M.joueurs[id]).filter(Boolean); const a = L.length ? L.reduce((t, j) => t + ((j.cache && j.cache.ada) || 11), 0) / L.length : 11; return borne(1 + (11 - a) * 0.04, 0.7, 1.3); });
  { const g = (e1.rep || 60) - (e0.rep || 60); if (Math.abs(g) >= SP.outsider){ const o = g > 0 ? 0 : 1; X.moral[o] = borne(X.moral[o] + 0.4, -3, 3); X.jour[1 - o] *= 0.985; } }
  X.fat0 = {...X.fat};   // v96 : fatigue au coup d'envoi (la charge se calcule sur l'effort du match)
  X.arb = arbitrePour(graine); X.cartons = []; X.exclus = [[], []];   // v158 : arbitre du match, cartons, joueurs exclus de chaque équipe
  dire(X, 'debut', -1, {}, true);
  return X;
}
const J = (X, id) => X.M.joueurs[id];
/* v158 : arbitre tiré d'après la graine du match (le même avant et pendant le match) */
function arbitrePour(graine){ const A = D.ARBITRES, a = A[Math.floor(hasard(melange(graine, 'arbitre'))() * A.length)]; return {nom:a[0], nat:a[1], sev:a[2], k:a[2] >= 1.15 ? 'severe' : a[2] <= 0.9 ? 'laxiste' : 'normal'}; }
/* v158 : qui commet la faute (agressivité, tête brûlée, rôles au contact ; un joueur déjà averti se retient) */
function fautif(X, d){ const e = X.e[d];
  return X.r.pondere([...e.P.map(id => [id, 1]), ...e.B.map(id => [id, 0.8])].map(([id, w]) => { const j = J(X, id), r = role(X, d, id);
    return [id, w * (0.5 + at(j, 'agr') / 12) * (aManie(j, 'tete') ? 1.5 : 1) * ({harceleur:1.3, briseur:1.3, traqueur:1.2, pivot:1.15}[r] || 1) * (X.cartons.some(c => c.id === id) ? 0.55 : 1)]; })); }
/* v158 : carton (jaune, second jaune, rouge direct) ; un exclu quitte le terrain sans remplaçant, sauf s'il est le dernier de son poste */
function sanctionner(X, d, id, grave){
  const r = X.r, F = EQ.fautes, sev = X.arb ? X.arb.sev : 1, deja = X.cartons.some(c => c.id === id && c.c === 'j'), j = J(X, id), v = {j:nomJ(j), r:X.arb ? X.arb.nom : 'l\'arbitre'};
  let c = null;
  if (grave && r() < F.rouge * sev) c = 'r';
  else if (r() < (grave ? 0.9 : F.jaune * (0.7 + at(j, 'agr') / 30)) * sev) c = deja ? 'j2' : 'j';
  if (!c) return;
  X.cartons.push({id, eq:d, c, t:X.t}); X.stats[d].cj = (X.stats[d].cj || 0) + (c === 'j' ? 1 : 0); if (c !== 'j') X.stats[d].cr = (X.stats[d].cr || 0) + 1;
  if (c === 'j'){ dire(X, 'carton_jaune', d, v, false, {carton:'j', jc:id}); return; }
  const e = X.e[d], poste = ['P', 'B'].find(p => e[p].includes(id));
  dire(X, c === 'j2' ? 'second_jaune' : 'carton_rouge', d, v, true, {carton:'r', jc:id});
  if (poste && e[poste].length > 1){ e[poste] = e[poste].filter(x => x !== id); X.exclus[d].push(id); if (X.perf[id]) X.perf[id].out = X.t; X.levC = null; X.maC = null; X.moral[d] = borne(X.moral[d] - 0.3, -3, 3); }
}
function dire(X, cle, eq, v, cleEv, extra){
  const ev = {t:X.t, k:cle, e:eq, sc:X.score.slice(), cle:!!cleEv, ...(extra || {})};
  if (X.avecTexte){
    const s = `${X.score[0]}–${X.score[1]}`;
    ev.txt = texte(X.rt, cle, {s, m:Math.floor(X.t / 60), c:eq >= 0 ? X.e[eq].nom : '', a:eq >= 0 ? X.e[1 - eq].nom : '', ...v});
  }
  X.ev.push(ev); X.evNouv.push(ev);
}
const nomJ = j => j ? `${j.p} ${j.n}` : '?';
/* facteur de forme d'un joueur sur le terrain : fatigue, forme, moral de l'équipe */
function f(X, eq, id){ const j = J(X, id); if (!j) return 1; return (1 - X.fat[id] / 300) * (0.96 + j.forme * 0.008) * (1 + X.moral[eq] * 0.01) * (X.fj ? X.fj[id] || 1 : 1) * (X.enjeu ? 1 + (((j.cache && j.cache.gm) || 11) - 11) * EQ.surprise.gm : 1); }   // v153 : forme du jour du joueur (Régularité), matchs importants
const moy = L => L.reduce((s, x) => s + x, 0) / (L.length || 1);
const ajout = (o, k, v) => { if (o) o[k] = (o[k] || 0) + v; };   // v102 : compteur de stats sans tirage
const role = (X, eq, id) => (X.e[eq].roles || {})[id];
const nbRole = (X, eq, poste, r) => X.e[eq][poste].filter(id => role(X, eq, id) === r).length;
/* v152 : maîtrise du plan qu'une équipe joue (e.mEl : maîtrise de chaque option, « clé:valeur » ; sans carte : e.maitrise ou 60) */
function maitriseDe(mEl, T){ const P = EQ.maitrise.poids; let s = 0, n = 0; for (const k in P){ const v = mEl[k + ':' + T[k]]; s += P[k] * (v ?? EQ.maitrise.autre); n += P[k]; } return n ? s / n : EQ.maitrise.neutre; }
const maitriseEquipe = e => { if (!e.mEl) return e.maitrise ?? EQ.maitrise.neutre; const T = e.tactique, k = T.passes + T.sans + T.avec + T.batAvec + T.batSans + T.zone; if (e.mtC && e.mtC[0] === k) return e.mtC[1]; const v = maitriseDe(e.mEl, completerTactique(T)); e.mtC = [k, v]; return v; };
function moyP(L, w){ let s = 0, n = 0; L.forEach((v, i) => { s += v * w[i]; n += w[i]; }); return n ? s / n : 0; }
function forces(X, eq){
  const e = X.e[eq], T = e.tactique, b = e.balai;
  const us = 0.8 + 0.2 * (e.usure ?? 100) / 100;                                   // v84 : balais usés
  const mt = maitriseEquipe(e), km = (mt - EQ.maitrise.neutre) / 100 * EQ.maitrise.force;   // v152 : maîtrise du plan joué, élément par élément
  const coh = (0.97 + (e.cohesion ?? 70) / 100 * 0.06)                              // v84 : cohésion de l'équipe
    * (1 + km) * (1 + (e.mep || 0));   // v127 : mise en place ; v152 : maîtrise tactique (60 % neutre, 90 % +4,2 %, 30 % −4,2 %, plus de ballons perdus quand elle est basse)
  const dom = ((eq === 0 && X.domicile) ? EQ.domicile + (e.domBonus || 0) : 1) * X.jour[eq] * coh * (1 + (e.forceBonus || 0));   // v88 : dragon de pierre, carte du ciel
  const wA = e.P.map(() => 1), wD = e.P.map(() => 1);   // v153 : plus de pondération par rôle (les rôles agissent par leurs leviers)
  const pil = (L, p) => L.length ? 1 + L.reduce((t, id) => t + (J(X, id) ? at(J(X, id), 'pil') - typique(p, 'pil') : 0), 0) / L.length / 40 : 1;   // v153 : Pilotage (pilote typique = balai tel quel) ; v160 : deux fois plus marqué
  const infP = 1 - EQ.fautes.inf.P * Math.max(0, 3 - e.P.length), infB = 1 - EQ.fautes.inf.B * Math.max(0, 2 - e.B.length);   // v158 : infériorité numérique après un carton rouge
  const A = moyP(e.P.map(id => { const j = J(X, id); return ((at(j, 'pas') * 2 + at(j, 'rec') + at(j, 'ctl') * 2 + at(j, 'vis') * 2 + at(j, 'frm') + at(j, 'acc') + at(j, 'equi') + at(j, 'tir') + at(j, 'dec')) / 12) * f(X, eq, id);   /* v160 : + Décisions */ }), wA) * dom + (b.man * us * pil(e.P, 'P') - 6) * 0.12
    + 0.12 * e.P.filter(id => aManie(J(X, id), 'passeur')).length;   // v89 : manie « cherche la passe »
  const Df = moyP(e.P.map(id => { const j = J(X, id); return ((at(j, 'int') * 2 + at(j, 'bou') + at(j, 'ant') * 2 + at(j, 'pla') + at(j, 'vit') + at(j, 'acc') + at(j, 'con') + at(j, 'vir')) / 10) * f(X, eq, id);   /* v160 : + Concentration, Virages serrés */ }), wD) * dom * infP;
  const B = moy(e.B.map(id => { const j = J(X, id); return ((at(j, 'fra') * 3 + at(j, 'pre') * 2 + at(j, 'for') + at(j, 'ant') + at(j, 'agr')) / 8) * f(X, eq, id); })) * (dom > 1 ? 1.02 : 1) * (1 + km / 2);
  const g = J(X, e.G[0]);
  const G = g ? ((ga(g, 'arr') * 3 + ga(g, 'cou_a') * 2 + ga(g, 'sor') + at(g, 'ref') * 2 + at(g, 'agi') + at(g, 'pla') + at(g, 'ant') + at(g, 'con')) / 12) * f(X, eq, e.G[0]) + (aManie(g, 'mur') ? 0.35 : 0) : 5;   // v153 : le gardien de ligne passe par le levier « rempart »   // (v90 : gMalus = gardien soudoyé, appliqué plus bas)
  const s = J(X, e.A[0]);
  const S = s ? ((at(s, 'vit') * 2 + at(s, 'acc') * 2 + at(s, 'piq') * 2 + at(s, 'acu') * 2 + at(s, 'san') + at(s, 'con') + at(s, 'vir') + at(s, 'ref') + at(s, 'agi')) / 13) * f(X, eq, e.A[0]) + (b.vit * us * pil(e.A, 'A') - 6) * 0.15 : 5;   // v153 : Réflexes, Pilotage
  return {A:A * infP, D:Df, B:B * infB, G:G * (1 - (e.gMalus || 0)), S, T, mt};
}
function tireur(X, eq){
  const e = X.e[eq]; const p = e.P.map(id => { const j = J(X, id); return [id, Math.pow(at(j, 'tir') + at(j, 'pre') * 0.5, 2) * ({finisseur:nbRole(X, eq, 'P', 'finisseur') >= 2 ? 1.6 : 2.2, meneur:0.7}[role(X, eq, id)] || 1) * (aManie(j, 'loin') ? 1.35 : 1)]; });
  return X.r.pondere(p);
}
function qualiteTir(X, eq, id){ const j = J(X, id); return ((at(j, 'tir') * 3 + at(j, 'pre') * 2 + at(j, 'san') + at(j, 'ctl')) / 7) * f(X, eq, id) - (aManie(j, 'loin') ? 0.5 : 0); }
const nbManie = (X, eq, postes, k) => postes.split('').reduce((s, p) => s + X.e[eq][p].filter(id => aManie(J(X, id), k)).length, 0);
function batteur(X, eq){ const e = X.e[eq]; return X.r.pondere(e.B.map(id => [id, at(J(X, id), 'fra') + 2])); }

/* v96 : probabilités d'un pas quand l'équipe a attaque (Fa, Fd : forces des deux équipes). Utilisées par pas() et par l'analyse tactique. */
/* v153 : leviers d'une équipe à ce pas (rôles × qualité dans le rôle × forme ; meilleur contributeur en entier, puis 60 %, 35 %, 20 %),
   synergies et anti-synergies comprises ; l'attrapeur joue ses leviers « avant » tant que le vif n'est pas aperçu (ou s'il reste dans le jeu) */
function leviers(X, eq){
  const c = X.levC || (X.levC = [{}, {}]), tic = X.pas >> 2, md = (X.e[eq].tactique || {}).vifMode; if (c[eq].tic === tic && c[eq].vu === X.vifVu && c[eq].md === md && c[eq].fj === X.fj) return c[eq].L;   // recalculés chaque minute de jeu
  const e = X.e[eq], vu = X.vifVu, jeu = (e.tactique || {}).vifMode === 'jeu', parts = {};
  for (const p of ['P', 'B', 'A', 'G']) for (const id of e[p]){ const j = J(X, id); if (!j) continue; const r = role(X, eq, id), R = (D.ROLE_DEF[p] || {})[r]; if (!R) continue;
    const qk = id + ':' + r, QR = X.qr || (X.qr = {}); if (QR[qk] == null) QR[qk] = qualiteRole(j, p, r);   // qualité dans le rôle : fixe pendant le match
    const q = QR[qk] * f(X, eq, id);
    for (const l in R.lev){ let m = 1;
      if (p === 'A'){ const course = (R.course || []).includes(l); m = course ? (vu ? (jeu ? 0.85 : 1) : 0) : (!vu ? 1 : jeu ? 0.7 : 0); }   // v156 : « rester dans le jeu » moins coûteux
      if (m) (parts[l] = parts[l] || []).push(R.lev[l] * q * m); } }
  const L = {}, dec = EQ.lev.decr;
  for (const l in parts){ const v = parts[l].sort((x, y) => y - x); L[l] = v.reduce((t, x, i) => t + x * (dec[i] ?? 0.1), 0); }
  if (!X.synC) X.synC = [null, null];
  const sig = [...e.P, ...e.B, ...e.A, ...e.G].map(id => id + ':' + role(X, eq, id)).join();
  if (!X.synC[eq] || X.synC[eq].sig !== sig) X.synC[eq] = {sig, S:synergiesDe(X.M, e).filter(x => x.ok), A:antiSynergiesDe(X.M, e)};
  for (const S of X.synC[eq].S){ if (S.avant && vu) continue; for (const l in S.lev) L[l] = (L[l] || 0) + S.lev[l]; }
  if (X.synC[eq].A.some(a => a.id === 'briseurs')) L.bouclier = (L.bouclier || 0) * 0.5;
  c[eq] = {tic, vu, md, fj:X.fj, L}; if (eq === 0) X.maC = null; return L;
}
/* v153 : élan. L'équipe menée de plus de 5 buts se jette à l'attaque, celle qui mène se relâche un peu (l'écart se resserre, le vif d'or garde du sens) */
const elan = (X, a) => { const g = ((X.stats[1 - a].buts || 0) - (X.stats[a].buts || 0)); return g > 5 ? EQ.surprise.elan * Math.min(8, g - 5) : g < -5 ? -EQ.surprise.elan / 2 * Math.min(8, -g - 5) : 0; };
const lv = (L, k) => (L[k] || 0) - EQ.lev.ref[k];   // v153 : levier centré sur une équipe moyenne
const moyAttr = (X, eq, postes, k) => { const C = X.maC || (X.maC = {}), ck = eq + postes + k; if (C[ck] != null) return C[ck]; const L = postes.split('').flatMap(p => X.e[eq][p]).map(id => J(X, id)).filter(Boolean); return C[ck] = L.length ? L.reduce((t, j) => t + at(j, k), 0) / L.length : 12; };
function probas(X, a, Fa, Fd){
  const d = 1 - a, Ta = Fa.T, Td = Fd.T, met = X.meteo, e = X.e;
  const ag = 1 + 0.25 * (Td.agressivite - 2);
  const sd = sansDe(Td);   // v89 : disposition de la défense
  const La = leviers(X, a), Ld = leviers(X, d), LV = EQ.lev, ada = X.ada ? X.ada[a] : 1;   // v153
  const pCog = EQ.cognard * borne(1 + (Fd.B - Fa.B) / EQ.cogEchelle, 0.35, 2.1) * ag * (met === 'orage' ? 1.1 : 1) * Math.max(0.2, (1 - LV.bouclier * lv(La, 'bouclier')) * (1 + LV.marteau * lv(Ld, 'marteau'))) * borne(1 - 0.03 * (moyAttr(X, a, 'P', 'agi') - typique('P', 'agi')), 0.75, 1.25)
    * (Ta.batAvec === 'escorte' ? 0.9 : Ta.batAvec === 'devant' ? 1.1 : 1) * (Td.batSans === 'harcelement' ? 1.12 : Td.batSans === 'protection' ? 0.9 : 1) * (1 - 0.06 * nbManie(X, a, 'B', 'garde')) * (e[d].B.length < 2 ? 0.55 : 1) * (e[a].B.length < 2 ? 1.45 : 1);   // v158 : un batteur exclu
  const FF = EQ.fautes, pFaute = EQ.faute * (FF.agr[Td.agressivite] || 1) * (sansDe(Td) === 'pressing' ? FF.pressing : 1) * (Td.batSans === 'harcelement' ? FF.harcelement : 1) * (X.arb ? 0.85 + 0.15 * X.arb.sev : 1) *   // v158 : pressing, harcèlement, arbitre
    (1 + 0.12 * nbManie(X, a, 'P', 'provoc') + 0.1 * nbManie(X, d, 'PB', 'tete')) * borne(1 - 0.04 * (moyAttr(X, d, 'PB', 'con') - 9.6), 0.6, 1.4);   // v153 : Concentration
  const za = Ta.zone || 'axe', av = Ta.avec || 'triangle';   // v89 : zone d'attaque et disposition avec le souafle
  /* v157 : effets des consignes lus dans QMD.STYLE (attaque : ce que l'option change quand on a le souafle ; défense : quand l'adversaire l'a),
     multipliés par EQ.style.k pour que les choix tactiques donnent des matchs et des équipes qui se reconnaissent */
  const SA = effetsStyle(Ta, 'att'), SD = effetsStyle(Td, 'def'), K = EQ.style.k;
  const dur = Td.agressivite === 3 ? EQ.style.duel * borne(1 + (moyAttr(X, d, 'PB', 'for') + moyAttr(X, d, 'P', 'bou') - moyAttr(X, a, 'P', 'for') - moyAttr(X, a, 'P', 'equ')) / 12, 0.4, 1.8) : 0;   // duels gagnés par une défense physique
  const fTir = borne(1 + K * (SA.tir + SD.tir), 0.45, 1.8);   // v157 : les consignes multiplient le nombre de tirs (un bloc contre un bloc tire deux fois moins)
  const dTir = (Td.gardien === 'sortie' ? -0.03 : 0) + (met === 'pluie' || met === 'orage' ? -0.03 * ada * (1 - (e[a].meteoRes || 0)) : 0) + (role(X, d, e[d].G[0]) === 'libero' ? -0.03 : 0)
    + elan(X, a) + (X.cfNow === a ? EQ.fautes.cf : 0) + LV.constr * lv(La, 'constr') + (X.contreNow === a ? EQ.style.contre + (sansDe(Ta) === 'repli' ? EQ.style.contreRepli : 0) + LV.contre * lv(La, 'contre') : 0) + (za === 'couloirs' ? 0.015 * nbRole(X, a, 'P', 'ailier') : 0);   // v153 : leviers ; v157 : contre (plus fort pour une équipe repliée)
  const pTir = Math.min(0.9, borne(1 / (1 + Math.exp(-((Fa.A - Fd.D) / EQ.echelleTir + EQ.baseTir))) + dTir, 0.12, 0.85) * fTir);
  const dBut = K * (SA.but + SD.but) + (CONTRE[sd] === za ? 0.03 : 0)
    + (Td.gardien === 'sortie' ? 0.03 : 0) + (met === 'vent' || met === 'orage' ? -0.04 * ada * (1 - (e[a].meteoRes || 0)) : 0) + (role(X, d, e[d].G[0]) === 'libero' ? 0.02 + (nbRole(X, d, 'B', 'gardeAnneaux') ? 0 : 0.01) : 0)
    + LV.finit * lv(La, 'finit') - LV.rempart * lv(Ld, 'rempart');   // v153 : leviers
  const tourne = 1 - EQ.garde - EQ.maitrise.pertes * ((Fa.mt ?? EQ.maitrise.neutre) - EQ.maitrise.neutre) / 100 + K * (SA.perte + SD.perte) + dur + (met === 'pluie' ? 0.03 * ada : 0) - LV.garde * lv(La, 'garde') + LV.recup * lv(Ld, 'recup');
  return {pCog, pFaute, pPenF:EQ.fautes.pen + (1 - EQ.fautes.pen) * EQ.fautes.grave, pTir, dBut, tourne, sd, za, av};
}
/* v96 : multiplicateur de fatigue d'une tactique, et poids de chaque poursuiveur au tir (pour l'analyse) */
const multFatigue = T => EQ.fatigue * (1 + 0.25 * (T.rythme - 2)) * (sansDe(T) === 'pressing' ? 1.15 : 1) * (T.agressivite === 3 ? 1.1 : 1);   // v157 : le jeu physique use
/* v157 : somme des effets des consignes d'une tactique (QMD.STYLE), côté attaque ou défense ; mise en cache par tactique */
const CACHE_STYLE = new Map();
function effetsStyle(T, cote){ const k = cote + (T.rythme) + T.risque + T.agressivite + T.passes + (T.sans || sansDe(T)) + T.avec + T.zone + T.batAvec + T.batSans; let r = CACHE_STYLE.get(k); if (r) return r;
  r = {tir:0, but:0, perte:0}; for (const [cle, opts] of Object.entries(D.STYLE)){ const v = cle === 'sans' ? sansDe(T) : T[cle], o = opts[String(v)]; const x = o && o[cote]; if (x){ r.tir += x[0]; r.but += x[1]; r.perte += x[2]; } }
  CACHE_STYLE.set(k, r); return r; }
function poidsTireurs(X, eq){ const e = X.e[eq]; return e.P.map(id => { const j = J(X, id); return [id, j ? Math.pow(at(j, 'tir') + at(j, 'pre') * 0.5, 2) * ({finisseur:nbRole(X, eq, 'P', 'finisseur') >= 2 ? 1.6 : 2.2, meneur:0.7}[role(X, eq, id)] || 1) * (aManie(j, 'loin') ? 1.35 : 1) : 0]; }); }
/* un pas de 15 s ; renvoie les événements produits */
function pas(X){
  if (X.fini) return [];
  X.evNouv = [];
  const r = X.r, a = X.poss, d = 1 - a, Fa = forces(X, a), Fd = forces(X, d), Ta = Fa.T, Td = Fd.T, met = X.meteo;
  X.stats[a].poss = (X.stats[a].poss || 0) + 1;   // v97 : possession (pas joués avec le souafle)
  const e = X.e;
  X.t += EQ.pas; X.pas++;
  X.contreNow = X.contre && X.contre[a] ? a : -1; X.contre = [0, 0]; X.cfNow = X.cf === a ? a : -1; X.cf = -1;   // v158 : coup franc   // v153 : contre-attaque après une récupération ou un arrêt
  for (const k of [0, 1]){ if (X.sonne[k] > 0) X.sonne[k]--; if (X.gSonne[k] > 0) X.gSonne[k]--; }
  /* fatigue de tous les joueurs sur le terrain */
  for (const k of [0, 1]){ const T = e[k].tactique; const mult = multFatigue(T);
    const rA = role(X, k, e[k].A[0]), mA = X.vifVu ? 1 : rA === 'chasseur' ? 0.6 : rA === 'perturbateur' ? 1.3 : 1;   // v153 : l'attrapeur qui participe s'use
    for (const id of titulaires(e[k])){ const j = J(X, id); if (j) X.fat[id] = Math.min(100, X.fat[id] + mult * (1.6 - at(j, 'end') / 20) * (id === e[k].A[0] ? mA : 1)); } }

  /* 1. cognards de la défense */
  const P = probas(X, a, Fa, Fd), sd = P.sd;   // v96 : probabilités du pas partagées avec l'analyse tactique (qm27-tactique.js)
  if (r() < P.pCog){
    const bat = batteur(X, d); X.stats[d].cog++; X.perf[bat].cog++;
    const cible = Td.cible;
    const victime = cible === 'attrapeur' ? e[a].A[0] : cible === 'gardien' ? e[a].G[0] : r.choix(e[a].P);
    if (cible === 'attrapeur'){   // v153 : l'ange gardien et l'agilité de l'attrapeur
      const sa = J(X, victime), prot = Math.min(0.85, EQ.lev.ange * (leviers(X, a).ange || 0) + (sa ? Math.max(0, at(sa, 'agi') - typique('A', 'agi')) * 0.02 : 0));
      if (r() < prot){ dire(X, 'cognard_devie', a, {j:nomJ(sa)}, false); return finPas(X); }
      X.sonne[a] = 12 + (X.synC && X.synC[d] && X.synC[d].S.some(x => x.id === 'peine') ? 4 : 0); dire(X, 'cognard_att', d, {j:nomJ(J(X, bat))}, false); }
    else if (cible === 'gardien'){ X.gSonne[a] = X.synC && X.synC[a] && X.synC[a].S.some(x => x.id === 'mur') ? 4 : 8; dire(X, 'cognard_gar', d, {j:nomJ(J(X, bat))}, false); X.poss = d; X.contre[d] = 1; }
    else { const v = J(X, victime), garde = v ? borne(0.025 * (at(v, 'equ') + at(v, 'cou') - 16.2) + (role(X, a, victime) === 'pivot' ? 0.12 : 0) - 0.02 * (at(J(X, bat), 'pre') - typique('B', 'pre')), 0, 0.5) : 0;   // v160 : la Précision du batteur   // v153 : Équilibre sur balai, pivot
      if (r() < garde) dire(X, 'cognard_tenu', a, {j:nomJ(v)}, false); else { dire(X, 'cognard', d, {j:nomJ(J(X, bat))}, false); X.poss = d; X.contre[d] = 1; } }
    /* blessure possible de la cible */
    const vj = J(X, victime);
    if (vj && r() < EQ.blessure * (vj.cache.frag / 10) * (1 + 0.3 * (Td.agressivite - 2)) * (met === 'orage' ? 1.3 : 1) * (1.4 - at(vj, 'res') / 25) * Math.max(0.5, 1 + 0.5 * lv(leviers(X, d), 'marteau')) * (aManie(J(X, bat), 'cogneur') ? 1.3 : 1) * (cible === 'attrapeur' && role(X, a, victime) === 'leurre' ? 1.3 : 1) * (1 + (vj.charge || 0) / 110)){ ajout(X.perf[bat], 'bc', 1); X.stats[d].bc = (X.stats[d].bc || 0) + 1; blesser(X, a, victime); }   // v102 : blessures causées
    return finPas(X);
  }
  /* 2. faute */
  if (r() < P.pFaute){
    const fid = fautif(X, d); X.stats[d].fautes++; if (X.perf[fid]) X.perf[fid].f = (X.perf[fid].f || 0) + 1;   // v97 : fautes par joueur ; v158 : qui la commet
    const FF = EQ.fautes, grave = r() < FF.grave * (Td.agressivite === 3 ? 1.3 : Td.agressivite === 1 ? 0.6 : 1) * (0.6 + at(J(X, fid), 'agr') / 25), pen = grave || r() < FF.pen;
    X.fat[fid] = Math.min(100, (X.fat[fid] || 0) + FF.fatigue * 4);   // le contact use
    dire(X, grave ? 'faute_grave' : pen ? 'faute' : 'faute_cf', d, {j:nomJ(J(X, fid)), r:X.arb ? X.arb.nom : 'l\'arbitre'}, grave, {fj:fid});
    sanctionner(X, d, fid, grave);
    if (!pen){ X.cf = a; return finPas(X); }   // v158 : coup franc (l'action suivante est plus dangereuse)
    const ti = e[a].pen && e[a].P.includes(e[a].pen) && J(X, e[a].pen) ? e[a].pen : tireur(X, a), T = qualiteTir(X, a, ti), G = Fd.G;   // v89 : tireur désigné
    X.stats[a].pen++; X.stats[a].tirs++; X.perf[ti].t++;
    const pPen = borne(EQ.penalty + 0.02 * (T - G), 0.4, 0.9); X.stats[a].xb = (X.stats[a].xb || 0) + pPen;
    ajout(X.perf[ti], 'pen', 1); ajout(X.perf[ti], 'xb', pPen); ajout(X.perf[e[d].G[0]], 'xbc', pPen);   // v102 : stats individuelles (aucun tirage en plus)
    if (r() < pPen){ ajout(X.perf[ti], 'penB', 1); marquer(X, a, ti, true); }
    else { X.stats[d].arrets++; if (e[d].G[0]){ X.perf[e[d].G[0]].arr++; ajout(X.perf[e[d].G[0]], 'penArr', 1); } dire(X, 'penalty_rate', a, {j:nomJ(J(X, ti)), g:nomJ(J(X, e[d].G[0]))}, false); X.poss = d; }
    return finPas(X);
  }
  /* 3. attaque */
  if (r() < P.pTir){
    const ti = tireur(X, a), T = qualiteTir(X, a, ti), G = Fd.G * (X.gSonne[d] > 0 ? 0.75 : 1) * (Ta.batAvec === 'devant' ? 0.97 : 1);
    const dBut = P.dBut;
    X.stats[a].tirs++; X.perf[ti].t++;
    const pBut = borne(EQ.baseBut + EQ.kBut * (T - G) + dBut, EQ.butMin, EQ.butMax); X.stats[a].xb = (X.stats[a].xb || 0) + pBut;   // v89 : buts attendus
    ajout(X.perf[ti], 'xb', pBut); ajout(X.perf[e[d].G[0]], 'xbc', pBut);   // v102
    if (r() < pBut) marquer(X, a, ti, false);
    else {
      const gk = e[d].G[0];
      if (r() < 0.78){ X.stats[d].arrets++; if (gk) X.perf[gk].arr++; if (T - G > 1.5 || r() < 0.25) dire(X, 'arret', a, {j:nomJ(J(X, ti)), g:nomJ(J(X, gk))}, false); }
      else { X.perf[ti].rate++; if (r() < 0.15) dire(X, 'rate', a, {j:nomJ(J(X, ti))}, false); }
      const gkj = J(X, gk); X.poss = r() < (aManie(gkj, 'relance') ? 0.8 : 0.7) + (gkj && gkj.g ? (ga(gkj, 'rel') - 12) * 0.01 : 0) ? d : a;   // v153 : Relance
      if (X.poss === d) X.contre[d] = 1;
    }
  } else {
    if (r() < P.tourne){ X.poss = d; X.contre[d] = 1; }
  }
  return finPas(X);
}
function marquer(X, eq, ti, penalty){
  X.score[eq] += EQ.points.but; X.stats[eq].buts++; X.perf[ti].b++; if (X.contreNow === eq) X.stats[eq].bc = (X.stats[eq].bc || 0) + 1;   // v157 : buts sur contre-attaque
  const gk = X.e[1 - eq].G[0]; if (gk) X.perf[gk].enc++;
  X.moral[eq] = borne(X.moral[eq] + 0.4, -3, 3); X.moral[1 - eq] = borne(X.moral[1 - eq] - (X.e[1 - eq].cap ? 0.25 : 0.4) * borne(1 - 0.04 * (moyAttr(X, 1 - eq, 'PBAG', 'det') - 9.7), 0.6, 1.3), -3, 3);   // v153 : Détermination
  dire(X, penalty ? 'penalty_but' : 'but', eq, {j:nomJ(J(X, ti)), g:nomJ(J(X, gk))}, false, {but:1});
  X.poss = 1 - eq;
}
function tirerBlessure(r){ const b = r.pondere(D.BLESSURES.map(x => [x, x[3]])); return {nom:b[0], jours:r.ent(b[1], b[2])}; }
function blesser(X, eq, id){
  const b = tirerBlessure(X.r), j = J(X, id);
  X.bless.push({id, eq, ...b});
  dire(X, 'blessure', eq, {j:nomJ(j), b:b.nom.toLowerCase()}, true, {blesse:id});
  /* remplacement sur blessure (hors des 3 libres) : premier remplaçant du même poste, sinon le meilleur */
  const e = X.e[eq], poste = ['P', 'B', 'A', 'G'].find(p => e[p].includes(id));
  const sorti = new Set(X.sortis || []);
  const cand = (e.banc || []).filter(x => !sorti.has(x) && J(X, x) && !X.bless.some(bb => bb.id === x));
  if (!cand.length) return;
  const n = cand.slice().sort((a, b) => note20(J(X, b), poste) - note20(J(X, a), poste))[0];
  remplacer(X, eq, id, n, true);
}
function remplacer(X, eq, sort, entre, blessure){
  const e = X.e[eq], poste = ['P', 'B', 'A', 'G'].find(p => e[p].includes(sort));
  if (!poste || !(e.banc || []).includes(entre)) return false;
  if (!blessure){ if (X.rempl[eq] <= 0) return false; X.rempl[eq]--; }
  e[poste] = e[poste].map(x => x === sort ? entre : x);
  e.banc = e.banc.filter(x => x !== entre);
  (X.sortis = X.sortis || []).push(sort);
  X.perf[entre] = X.perf[entre] || {eq, b:0, t:0, arr:0, cog:0, enc:0, vif:0, rate:0, m:0}; X.perf[entre].m = 1;
  X.perf[entre].in = X.t; if (X.perf[sort]) X.perf[sort].out = X.t;   // v102 : minutes jouées
  dire(X, 'remplacement', eq, {j:nomJ(J(X, entre)), k:nomJ(J(X, sort))}, false);
  return true;
}
function finPas(X){
  vifDor(X);
  if (!X.fini && X.t >= EQ.vifMaxMin * 60) finir(X, forces(X, 0).S >= forces(X, 1).S ? 0 : 1, true);
  return X.evNouv;
}
function vifDor(X){
  if (X.fini) return;
  const r = X.r;
  if (X.t < X.vifApp) return;
  if (!X.vifVu){ X.vifVu = true; X.vifDepuis = X.t; dire(X, 'vif_apercu', -1, {}, true, {vif:'vu'}); return; }
  if (X.vifCache > 0){ X.vifCache--; if (!X.vifCache) dire(X, 'vif_apercu', -1, {}, false, {vif:'revu'}); return; }
  if (r() < EQ.vifCache){ X.vifCache = r.ent(8, 32); dire(X, 'vif_cache', -1, {}, false); return; }
  const tmin = (X.t - X.vifDepuis) / 60, met = X.meteo === 'brouillard' ? 0.7 : X.meteo === 'orage' ? 0.85 : 1;
  const tardif = X.t > 200 * 60 ? 5 : 1;
  const ordre = r() < 0.5 ? [0, 1] : [1, 0];
  for (const k of ordre){
    const F = forces(X, k), T = X.e[k].tactique, To = X.e[1 - k].tactique;
    let p = EQ.p0 * (F.S / EQ.vifRef) * (1 - (1 - met) * (1 - (X.e[k].meteoRes || 0))) * (1 + tmin / 30) * tardif * (1 + (X.e[k].vifBonus || 0));
    if (X.sonne[k] > 0) p *= 0.5;
    const rs = role(X, k, X.e[k].A[0]), ro = role(X, 1 - k, X.e[1 - k].A[0]);
    p *= Math.max(0.5, 1 + EQ.lev.vif * lv(leviers(X, k), 'vif')) * Math.max(0.3, 1 - EQ.lev.gene * lv(leviers(X, 1 - k), 'gene')) * (T.vifMode === 'jeu' ? 0.9 : 1);   // v153 : leviers « vif » et « gêne »
    { const sj = J(X, X.e[k].A[0]); if (aManie(sj, 'feinte')) p *= 1.06; if (aManie(sj, 'oeil')) p *= 1.04; }   // v89 : manies de l'attrapeur
    if (T.attrapeur === 'marquage') p *= 0.6;
    if (To.attrapeur === 'marquage') p *= ro === 'tacticien' ? 0.55 : 0.65;
    if (r() < p){
      const sid = X.e[k].A[0], s = J(X, sid);
      const perdant = X.score[k] + EQ.points.vif < X.score[1 - k];
      if (perdant && T.attrapeur !== 'chasse' && r() < EQ.refus + (s ? at(s, 'dec') : 10) * 0.004 + (rs === 'tacticien' ? 0.08 : 0)){
        if (!X.refusDit || X.t - X.refusDit > 240){ X.refusDit = X.t; dire(X, 'vif_refus', k, {j:nomJ(s)}, false); }
        continue;
      }
      finir(X, k, false); return;
    }
    if (r() < 0.012 && X.avecTexte) dire(X, 'vif_poursuite', k, {j:nomJ(J(X, X.e[k].A[0]))}, false);
  }
}
function finir(X, k, force){
  X.score[k] += EQ.points.vif; X.vif = k; X.fini = true;
  const sid = X.e[k].A[0]; if (X.perf[sid]){ X.perf[sid].vif = 1; X.perf[sid].vifT = X.t; }
  X.avantVif = X.score.slice(); X.avantVif[k] -= EQ.points.vif;   // v102 : score juste avant le vif (matchs gagnés ou perdus au vif)
  const perdu = X.score[k] < X.score[1 - k];
  dire(X, perdu ? 'fin_perdu' : 'vif_attrape', k, {j:nomJ(J(X, sid))}, true, {vif:'pris', fin:1});
}
function jusquAuBout(X){ while (!X.fini) pas(X); return X; }
function tempsMort(X, eq){ if (X.tm[eq] <= 0 || X.fini) return false; X.tm[eq]--; dire(X, 'temps_mort', eq, {}, false); return true; }

/* notes des joueurs (sur 10) après le match */
function notesMatch(X){
  const N = {};
  for (const [id, p] of Object.entries(X.perf)){
    if (!p.m) continue;
    const g = Math.sign(X.score[p.eq] - X.score[1 - p.eq]);
    const ca = (X.cartons || []).filter(c => c.id === id), cn = ca.some(c => c.c !== 'j') ? -1.2 : ca.length ? -0.2 : 0;   // v158 : cartons
    const n = 6 + p.b * 0.22 + p.arr * 0.08 + p.cog * 0.25 - p.enc * 0.035 + p.vif * 1.6 - p.rate * 0.05 + (p.t ? (p.b / p.t - 0.4) * 1.2 : 0) + g * 0.3 + cn;
    N[id] = Math.round(borne(n, 3, 10) * 10) / 10;
  }
  return N;
}
function resume(X){ return {score:X.score.slice(), vif:X.vif, duree:Math.round(X.t / 60), meteo:X.meteo, stats:X.stats, notes:notesMatch(X), bless:X.bless.map(b => ({id:b.id, nom:b.nom, jours:b.jours})), ca:(X.cartons || []).map(c => [c.id, c.eq, c.c, Math.floor(c.t / 60)]), arb:X.arb ? X.arb.nom : null}; }   // v158 : cartons et arbitre

/* ---------- Semaine ---------- */
const semaine = M => M.calendrier[M.semaine] || null;
/* v85 : le club du joueur (null s'il est sans club) et son camp de la semaine (club, ou sa sélection pendant le Six Nations) */
const clubJoueur = M => (M.manager && M.manager.club) || null;
const campJoueur = (M, S) => S && S.type === 'sixn' ? (M.manager && M.manager.selection ? M.manager.selection.nat : null) : clubJoueur(M);
const natJoueur = M => M.manager && M.manager.selection ? M.manager.selection.nat : null;
const campPour = (M, m) => m.ligue === 'sixn' ? natJoueur(M) : clubJoueur(M);
/* v91 : les matchs du joueur cette semaine (sa sélection d'abord, puis son club) ; matchDuJoueur = le premier pas encore joué */
function matchsDuJoueur(M){
  const S = semaine(M); if (!S) return [];
  const n = natJoueur(M), c = clubJoueur(M);
  return [n && S.matchs.find(m => m.ligue === 'sixn' && (m.dom === n || m.ext === n)), c && S.matchs.find(m => m.ligue === 'eu' && (m.dom === c || m.ext === c)),   // v104 : la Ligue des Anneaux (mercredi) avant le championnat (samedi)
    c && S.matchs.find(m => m.ligue !== 'sixn' && m.ligue !== 'eu' && (m.dom === c || m.ext === c))].filter(Boolean);
}
function matchDuJoueur(M){ const L = matchsDuJoueur(M); return L.find(m => !m.res) || L[L.length - 1] || null; }
/* v91 : convocations de la semaine — les joueurs retenus par leur sélection manquent le match de leur club */
function convoquer(M){
  for (const j of Object.values(M.joueurs)) if (j.inter) delete j.inter;
  const S = semaine(M); if (!S || !S.matchs.some(m => m.ligue === 'sixn')) return;   // v161 : toutes les semaines de sélection (trêves amicales comprises), pas seulement quand les clubs jouent
  const moi = natJoueur(M);
  for (const n of D.SELECTIONS.filter(x => S.matchs.some(m => m.ligue === 'sixn' && (m.dom === x || m.ext === x)))){
    const e = n === moi && C() ? C().convocation(M).compo : selection(M, n);
    for (const id of [...titulaires(e), ...(e.banc || [])]) if (M.joueurs[id]) M.joueurs[id].inter = n;
  }
  /* v161 : le joueur est prévenu des convocations de ses joueurs (une fois par semaine de sélection) */
  const c = clubJoueur(M) && M.clubs[clubJoueur(M)], L = c ? c.effectif.map(id => M.joueurs[id]).filter(j => j && j.inter) : [];
  if (c && L.length && M.convMsg !== S.date){ M.convMsg = S.date;
    const nm = n => (D.NATIONS[n] || {nom:n}).nom, nb = n => S.matchs.filter(m => m.ligue === 'sixn' && (m.dom === n || m.ext === n)).length, cp = (S.matchs.find(m => m.ligue === 'sixn') || {}).comp === 'ldn' ? 'la Ligue des nations' : 'les matchs amicaux de la trêve';
    message(M, `${L.length} joueur${L.length > 1 ? 's' : ''} en sélection`, `Convoqués pour ${cp} : ${L.map(j => `${nomJ(j)} (${nm(j.inter)}, ${nb(j.inter)} match${nb(j.inter) > 1 ? 's' : ''})`).join(', ')}. Ils rentrent la semaine prochaine${S.matchs.some(m => m.ligue !== 'sixn') ? ' et manquent les matchs de club de cette semaine' : ''}.`, 'sixn'); }
}
const convoques = (M, clubId) => (M.clubs[clubId] ? M.clubs[clubId].effectif : []).filter(id => M.joueurs[id] && M.joueurs[id].inter);
function grainePour(M, m){ return melange(M.graine, m.id); }
function equipesPour(M, m){
  if (m.ligue === 'sixn') return [selection(M, m.dom), selection(M, m.ext)];
  const E = [equipeClub(M, m.dom), equipeClub(M, m.ext)];
  /* v152 : les clubs de l'ordinateur choisissent leur tactique pour ce match (plan, lecture de l'adversaire, absents, erreurs) */
  if (root.QMG && root.QMG.tactiqueMatch) E.forEach((e, k) => { const c = M.clubs[e.id]; if (!c || clubJoueur(M) === c.id) return;
    const R = root.QMG.tactiqueMatch(M, c, e, M.clubs[E[1 - k].id], E[1 - k], m); e.tactique = R.T; e.notesIA = R.notes; e.mEl = {...c.maitrise.el}; });
  if (root.QMB) E.forEach((e, k) => Object.assign(e, root.QMB.bonusMatch(M, M.clubs[e.id], M.clubs[E[1 - k].id])));   // v88 : bonus du domaine
  if (root.QMH) E.forEach(e => Object.assign(e, root.QMH.bonusMatch(M, M.clubs[e.id])));   // v90 : ambiance du vestiaire
  return E;
}
/* le match du joueur, prêt à être joué en direct */
function preparerMatch(M, m){
  const camp = campPour(M, m);
  let faits = [], e0, e1;
  if (m.ligue !== 'sixn'){
    for (const id of [m.dom, m.ext]) if (id !== camp){ M.clubs[id].compo = compoAuto(M, id); }
    faits = verifierCompo(M, camp);
    [e0, e1] = equipesPour(M, m);
  } else {   // v85 : le joueur est sélectionneur
    const moi = C().equipeSelection(M), autre = selection(M, m.dom === camp ? m.ext : m.dom);
    faits = moi.changements || [];
    [e0, e1] = m.dom === camp ? [moi, autre] : [autre, moi];
  }
  const X = creerMatch(M, e0, e1, grainePour(M, m), {date:semaine(M).date, domicile:!m.neutre, enjeu:enjeuDe(M, m)});
  X.idMatch = m.id; X.joueur = m.dom === camp ? 0 : 1; X.changements = faits; X.sixn = m.ligue === 'sixn';
  if (!X.sixn && root.QMG && root.QMG.attendue) X.attendue = root.QMG.attendue(M, M.clubs[X.e[1 - X.joueur].id]);   // v152 : ce que l'adjoint attendait d'eux
  return X;
}
/* v153 : un match à enjeu (attribut caché « matchs importants ») : phase finale d'une coupe, finale, ou choc entre deux des quatre premiers après la 10e journée */
function enjeuDe(M, m){
  if (m.neutre || (m.tour && !/^g/.test(m.tour))) return true;
  const L = M.ligues[m.ligue]; if (!L || M.semaine < 14) return false;
  const T = M.tables[m.ligue]; if (!T) return false; const CL = classement(M, m.ligue), rg = id => CL.findIndex(x => x.id === id);
  return rg(m.dom) >= 0 && rg(m.dom) < 4 && rg(m.ext) >= 0 && rg(m.ext) < 4;
}
function simulerMatch(M, m){
  if (m.ligue !== 'sixn') for (const id of [m.dom, m.ext]) M.clubs[id].compo = compoAuto(M, id);
  const [e0, e1] = equipesPour(M, m);
  return jusquAuBout(creerMatch(M, e0, e1, grainePour(M, m), {date:semaine(M).date, texte:false, domicile:!m.neutre, enjeu:enjeuDe(M, m)}));
}
/* v102 : statistiques de la saison (championnat seulement). Joueur : ajoutées à j.saison ; équipes : M.statsC[club], remis à zéro
   avec les classements. Rien ici ne tire au hasard : les résultats restent identiques à graine égale. */
function statsJoueur(s, p, X, id, notes){
  const min = Math.max(0, ((p.out ?? X.t) - (p.in ?? 0)) / 60);
  ajout(s, 'mn', Math.round(min)); ajout(s, 'tit', p.tit ? 1 : 0); ajout(s, 't', p.t || 0); ajout(s, 'f', p.f || 0); ajout(s, 'enc', p.enc || 0);
  s.xb = Math.round(((s.xb || 0) + (p.xb || 0)) * 100) / 100; s.xbc = Math.round(((s.xbc || 0) + (p.xbc || 0)) * 100) / 100;
  for (const k of ['pen', 'penB', 'penArr', 'bc']) if (p[k]) ajout(s, k, p[k]);
  if (p.vifT) ajout(s, 'vifT', Math.round(p.vifT / 60));
  const top = Object.entries(notes).sort((a, b) => b[1] - a[1])[0]; if (top && top[0] === id) ajout(s, 'mvp', 1);
}
const statsVides = () => ({j:0, bm:0, be:0, tirs:0, tirsC:0, xb:0, xbc:0, poss:0, pasT:0, fautes:0, pen:0, penC:0, arr:0, arrC:0, cog:0, cogS:0, bc:0, bl:0, blJ:0,
  vifs:0, duree:0, vifSauve:0, vifPerdu:0, ptsDom:0, jDom:0, ptsExt:0, jExt:0, serie:0, serieMax:0});
function statsEquipes(M, m, X){
  if (!M.statsC){ M.statsC = {}; M.statsDepuis = (semaine(M) || {}).journee || 0; }   // partie commencée avant v102 : le suivi démarre maintenant
  const S = M.statsC, st = X.stats;
  for (const k of [0, 1]){
    const id = k ? m.ext : m.dom, o = S[id] || (S[id] = statsVides()), a = st[k], b = st[1 - k];
    o.j++; o.bm += a.buts; o.be += b.buts; o.tirs += a.tirs; o.tirsC += b.tirs; o.xb = Math.round((o.xb + (a.xb || 0)) * 100) / 100; o.xbc = Math.round((o.xbc + (b.xb || 0)) * 100) / 100;
    o.poss += a.poss || 0; o.pasT += (a.poss || 0) + (b.poss || 0); o.fautes += a.fautes; o.pen += a.pen; o.penC += b.pen; o.arr += a.arrets; o.arrC += b.arrets;
    o.cog += a.cog; o.cogS += b.cog; o.bc += a.bc || 0; o.cj = (o.cj || 0) + (a.cj || 0); o.cr = (o.cr || 0) + (a.cr || 0);   // v158 : cartons
    const bl = X.bless.filter(x => x.eq === k); o.bl += bl.length; o.blJ += bl.reduce((t, x) => t + (M.joueurs[x.id] && M.joueurs[x.id].bless ? M.joueurs[x.id].bless.jours : x.jours), 0);
    o.duree += Math.round(X.t / 60); if (X.vif === k) o.vifs++;
    const s1 = X.score[k], s2 = X.score[1 - k], pts = s1 > s2 ? EQ.points.victoire : s1 === s2 ? EQ.points.nul : 0;
    if (X.avantVif && X.vif >= 0){ const av = X.avantVif; if (X.vif === k && av[k] <= av[1 - k] && s1 > s2) o.vifSauve++; if (X.vif !== k && av[k] > av[1 - k] && s1 <= s2) o.vifPerdu++; }
    if (k === 0){ o.ptsDom += pts; o.jDom++; } else { o.ptsExt += pts; o.jExt++; }
    o.serie = s1 > s2 ? Math.max(0, o.serie) + 1 : s1 < s2 ? Math.min(0, o.serie) - 1 : 0; o.serieMax = Math.max(o.serieMax, o.serie);
  }
}
/* applique un match terminé : résultat, classement, stats, fatigue, blessures, forme */
function appliquerMatch(M, m, X){
  const r = resume(X);
  const camp = campPour(M, m), duJoueur = !!camp && (m.dom === camp || m.ext === camp);
  m.res = duJoueur ? r : {score:r.score, vif:r.vif, duree:r.duree};   // autres matchs : le score suffit (sauvegarde plus légère)
  compter(M, m);
  if (root.QMG && root.QMG.noterTactique) root.QMG.noterTactique(M, m, X);   // v152 : tactiques jouées (jeu habituel de chaque club)
  const notes = r.notes;
  const club = m.ligue !== 'sixn', enLigue = club && !!M.ligues[m.ligue];   // v104 : la Ligue des Anneaux est un match de club, hors des stats du championnat
  for (const k of [0, 1]){
    const e = X.e[k];
    const joues = new Set([...titulaires(e), ...(X.sortis || []).filter(id => X.perf[id] && X.perf[id].eq === k), ...((X.exclus || [])[k] || [])]);   // v161 : les exclus ont joué ; v106 : un remplacé ne compte que pour son équipe (il comptait deux fois)
    for (const id of joues){
      const j = M.joueurs[id]; if (!j || !X.perf[id] || !X.perf[id].m) continue;
      const n = notes[id];
      if (club && !enLigue && j.saison){ ajout(j.saison, 'em', 1); ajout(j.saison, 'eb', X.perf[id].b); if (n) j.saison.en = Math.round(((j.saison.en || 0) + n) * 10) / 10; }
      if (enLigue){ j.saison.m++; j.saison.b += X.perf[id].b; j.saison.v += X.perf[id].vif; j.saison.cog += X.perf[id].cog; j.saison.arr += X.perf[id].arr; if (n) j.saison.notes += n;
        statsJoueur(j.saison, X.perf[id], X, id, notes); }
      else if (!club){ j.sel = (j.sel || 0) + 1; j.selS = j.selS && j.selS[0] === M.saison ? [M.saison, j.selS[1] + 1] : [M.saison, 1];   // v103 : sélections (carrière, saison)
        const p = X.perf[id]; j.selB = (j.selB || 0) + p.b; j.selV = (j.selV || 0) + p.vif;   // v106 : stats des matchs de sélection (carrière, puis saison dans j.nS)
        if (!j.nS || j.nS.s !== M.saison) j.nS = {s:M.saison, m:0, b:0, v:0, cog:0, arr:0, notes:0, ldn:0};
        const x = j.nS; x.m++; x.b += p.b; x.v += p.vif; x.cog += p.cog; x.arr += p.arr; if (n){ x.notes = Math.round((x.notes + n) * 10) / 10; x.nn = (x.nn || 0) + 1; } if (m.comp === 'ldn') x.ldn++; }
      const effort = Math.max(0, (X.fat[id] ?? 0) - ((X.fat0 || {})[id] ?? 0));
      j.charge = Math.round(borne((j.charge || 0) + effort * chargeFacteur(j), 0, 100) * 10) / 10; j.jouS = 1;   // v96 : fatigue cumulée
      j.fat = Math.round(Math.min(100, X.fat[id] ?? j.fat)); j.joue = 1;
      if (n) j.forme = Math.round(borne(j.forme * 0.6 + n * 0.4, 1, 10) * 10) / 10;
      const g = Math.sign(X.score[k] - X.score[1 - k]); j.moral = borne(j.moral + g * 6 + (n ? (n - 6) * 3 : 0), 5, 100);
    }
  }
  for (const b of X.bless){ const j = M.joueurs[b.id]; if (j){ j.bless = {nom:b.nom, jours:C() && j.club ? C().dureeBlessure(M, j.club, b.jours) : b.jours}; if (enLigue && j.saison){ ajout(j.saison, 'bl', 1); ajout(j.saison, 'blJ', j.bless.jours); } } }
  if (!club){   // v161 : feuille de match des matchs internationaux (saison en cours) : [id, poste, note, buts, vif] par équipe, cartons
    const f = {c:[[], []], ca:r.ca};
    for (const [id, p] of Object.entries(X.perf)){ if (!p.m || !M.joueurs[id]) continue; const ps = ['P', 'B', 'A', 'G'].find(q => X.e[p.eq][q].includes(id)) || M.joueurs[id].poste;
      f.c[p.eq].push([id, ps, notes[id] || null, p.b || 0, p.vif ? 1 : 0]); }
    m.res.f = f; }
  if (club) sanctions(M, m, X, enLigue);   // v158 : suspensions purgées, cartons, nouvelles suspensions
  if (enLigue) statsEquipes(M, m, X);
  if (club) for (const id of [m.dom, m.ext]) if (M.clubs[id]) M.clubs[id].usure = Math.max(0, Math.round(((M.clubs[id].usure ?? 100) - EQ.usure * (1 - (root.QMB ? root.QMB.bonus(M.clubs[id], 'usure') : 0))) * 10) / 10);   // v84 : balais
}
/* v96 : fatigue cumulée (j.charge, 0-100). Elle monte avec l'effort des matchs (et un peu l'entraînement intense), plus vite pour
   les joueurs peu endurants et après 30 ans ; elle redescend lentement, beaucoup plus vite quand le joueur ne joue pas.
   Elle empêche la fatigue de redescendre à zéro (plancher = charge × EQ.charge.plancher) et augmente le risque de blessure. */
const chargeFacteur = j => EQ.charge.match * (1.3 - at(j, 'end') / 40) * (1 + Math.max(0, j.age - 30) * 0.04);
const plancherFatigue = j => Math.round((j.charge || 0) * EQ.charge.plancher);
/* fin de semaine : récupération, guérisons, IA, messages */
function recuperer(M, jours){
  for (const j of Object.values(M.joueurs)){
    const cj = j.club && M.clubs[j.club], rb = cj && root.QMB ? root.QMB.bonus(cj, 'recup') : 0;   // v88 : résidence, bains, thermes
    const ch = j.charge || 0, K = EQ.charge;
    if (ch){ j.charge = Math.max(0, Math.round((ch - (ch * K.baisse + K.fixe + (j.jouS ? 0 : K.repos)) * jours / 7 * (1 + rb)) * 10) / 10); }
    j.jouS = 0;
    j.fat = Math.max(plancherFatigue(j), Math.round(j.fat - jours * (5 + at(j, 'end') * 0.35) * (1 + rb)));
    if (j.bless){ j.bless.jours -= jours;
      if (j.bless.jours <= 0){ j.bless = null; j.forme = Math.max(3, Math.round((j.forme - 2) * 10) / 10);   // v84 : retour progressif
        if (clubJoueur(M) && j.club === clubJoueur(M)) message(M, `${nomJ(j)} est rétabli`, 'Il revient à l\'entraînement, encore un peu juste : sa forme remontera avec les matchs.', 'bless'); } }
    j.moral = Math.round(j.moral + (60 - j.moral) * 0.15);
  }
}
/* v158 : après un match de club, chaque suspendu des deux clubs purge un match ; puis les cartons du match (cinq jaunes = un match, second jaune = un, rouge direct = deux) */
function sanctions(M, m, X, enLigue){
  for (const cid of [m.dom, m.ext]){ const c = M.clubs[cid]; if (!c) continue;
    for (const id of c.effectif){ const j = M.joueurs[id]; if (j && j.susp){ j.susp.n--; if (j.susp.n <= 0){ delete j.susp; if (cid === clubJoueur(M)) message(M, `${nomJ(j)} a purgé sa suspension`, 'Il est de nouveau sélectionnable.', 'susp'); } } } }
  const F = EQ.fautes, exclus = new Set((X.cartons || []).filter(c => c.c === 'j2').map(c => c.id));
  for (const ca of X.cartons || []){ const j = M.joueurs[ca.id]; if (!j) continue;
    if (enLigue && j.saison) ajout(j.saison, ca.c === 'j' ? 'ja' : 'ro', 1);
    if (ca.c === 'j'){ if (exclus.has(ca.id)) continue; j.cj = (j.cj || 0) + 1; if (j.cj % F.accumul === 0) suspendre(M, j, 1, `${j.cj} cartons jaunes cette saison`); }
    else suspendre(M, j, F.susp[ca.c === 'j2' ? 'j2' : 'r'], ca.c === 'j2' ? 'exclu sur un second carton jaune' : 'carton rouge direct'); }
}
function suspendre(M, j, n, raison){
  j.susp = {n:((j.susp && j.susp.n) || 0) + n, r:raison};
  if (j.club && j.club === clubJoueur(M)) message(M, `Suspension : ${nomJ(j)}`, `${raison.charAt(0).toUpperCase() + raison.slice(1)} : suspendu pour ${j.susp.n} match${j.susp.n > 1 ? 's' : ''} de club. Ton adjoint le retire de la composition.`, 'susp');
}
function message(M, titre, corps, type){ M.boite.unshift({id:'m' + (M.prochainId++), date:(semaine(M) || {}).date || Date.now(), titre, corps, type:type || 'info', lu:false}); if (M.boite.length > 60) M.boite.length = 60; }

/* Joue toute la semaine : X = le match du joueur déjà terminé (ou null). Renvoie un résumé pour l'écran. */
function terminerSemaine(M, X){
  const S = semaine(M); if (!S) return null;
  const mj = matchDuJoueur(M);
  const avant = {};
  if (clubJoueur(M)) for (const id of M.clubs[clubJoueur(M)].effectif) avant[id] = !!M.joueurs[id].bless;
  M.tic = (M.tic || 0) + 1;                             // v85 : compteur de semaines sur toute la carrière
  for (const m of S.matchs){
    if (m.res) continue;
    if (mj && m.id === mj.id && X) appliquerMatch(M, m, X);
    else appliquerMatch(M, m, simulerMatch(M, m));
  }
  if (mj && mj.res){ if (mj.ligue === 'sixn'){ if (C()) C().apresMatchSelection(M, mj); } else apresMatchManager(M, mj); }
  if (root.QMG && root.QMG.semaineBancs) root.QMG.semaineBancs(M, S);   // v159 : limogeages en cours de saison
  /* messages : blessures de l'équipe, résumé */
  if (M.manager){
    const club = clubJoueur(M) ? M.clubs[clubJoueur(M)] : {effectif:[]};
    for (const id of club.effectif){ const j = M.joueurs[id]; if (j.bless && !avant[id]) message(M, `Blessure : ${nomJ(j)}`, `${j.bless.nom}. Indisponible environ ${j.bless.jours} jour${j.bless.jours > 1 ? 's' : ''}.`, 'bless'); }
    if (S.tour){
      const L = S.matchs.filter(m => m.ligue === 'sixn').map(m => `${D.NATIONS[m.dom].nom} ${m.res.score[0]}–${m.res.score[1]} ${D.NATIONS[m.ext].nom}`).join(' · ');
      message(M, `${D.TOURNOI.nom}, tour ${S.tour}`, L, 'sixn');
    }
  }
  if (C() && !(S.type === 'sixn' && S.comp)) C().semaine(M, S);   // v84 : entraînement, finances, mercato, contrats ; v106 : pas pendant une trêve internationale
  if (root.QMN) root.QMN.apresSemaine(M, S);          // v106 : amicaux, Ligue des nations (tableau final)
  const prochaine = M.calendrier[M.semaine + 1];
  const jours = prochaine ? Math.round((prochaine.date - S.date) / 864e5) : 7;
  recuperer(M, jours);
  M.semaine++;
  const N = semaine(M);
  if (N && N.type === 'bilan') finDeSaison(M);
  convoquer(M);
  if (M.manager && N && N.tour && clubJoueur(M)){ const L = convoques(M, clubJoueur(M)).map(id => nomJ(M.joueurs[id]));
    if (L.length) message(M, `${D.TOURNOI.court} : ${L.length} ${L.length > 1 ? 'internationaux absents' : 'international absent'}`, `Tour ${N.tour} du ${D.TOURNOI.nom} : ${L.join(', ')} ${L.length > 1 ? 'jouent' : 'joue'} avec ${L.length > 1 ? 'leur sélection' : 'sa sélection'} et ${L.length > 1 ? 'manqueront' : 'manquera'} le match du club.`, 'sixn'); }
  return S;
}
/* v91 : fin du match joué par le joueur. S'il lui reste un autre match cette semaine (sélection puis club), on l'applique seulement. */
function finirMatchDuJoueur(M, X){
  const L = matchsDuJoueur(M), m = L.find(x => x.id === X.idMatch), reste = L.some(x => x !== m && !x.res);
  if (m && reste){ appliquerMatch(M, m, X); if (m.ligue === 'sixn'){ if (C()) C().apresMatchSelection(M, m); } else apresMatchManager(M, m); return {semaineFinie:false, m}; }
  terminerSemaine(M, X); return {semaineFinie:true, m};
}
function attente(M, clubId, adv){ const a = M.clubs[clubId].rep, b = adv.rep || 60; return borne(0.5 + (a - b) / 60, 0.15, 0.85); }
function apresMatchManager(M, m){
  const mg = M.manager, k = m.dom === mg.club ? 0 : 1, [s0, s1] = m.res.score, moi = k ? s1 : s0, lui = k ? s0 : s1;
  const adv = M.clubs[k ? m.dom : m.ext];
  const att = attente(M, mg.club, adv), res = moi > lui ? 1 : moi === lui ? 0.5 : 0;
  mg.confiance = Math.round(borne(mg.confiance + (res - att) * 10, 0, 100));
  mg.rep = Math.round(borne(mg.rep + (res - att) * 1.6, 1, 100) * 10) / 10;
  mg.bilan = mg.bilan || {g:0, n:0, p:0}; mg.bilan[res === 1 ? 'g' : res === 0 ? 'p' : 'n']++;
  if (C() && C().verifierLicenciement) C().verifierLicenciement(M);   // v85
}

/* ---------- Objectifs du président ---------- */
function objectif(M, clubId){
  const club = M.clubs[clubId], L = M.ligues[club.ligue].clubs.map(id => M.clubs[id]).sort((a, b) => b.rep - a.rep);
  const rang = L.findIndex(c => c.id === clubId) + 1;
  const vise = rang <= 1 ? 1 : rang <= 3 ? 3 : rang <= 6 ? 6 : rang <= 10 ? 10 : rang <= 13 ? 13 : 16;
  const txt = vise === 1 ? 'Gagner le championnat' : vise === 3 ? 'Finir sur le podium' : vise === 6 ? 'Finir dans les 6 premiers' : vise === 10 ? 'Finir dans la première moitié' : vise === 13 ? 'Finir 13e ou mieux' : 'Progresser et lancer des jeunes';
  return {vise, txt};
}

/* ---------- Carrière ---------- */
function choisirClub(M, clubId, nom){
  const club = M.clubs[clubId];
  M.manager = {nom:(nom || 'Manager').slice(0, 30), club:clubId, rep:Math.round(18 + club.rep / 5), confiance:60, objectif:objectif(M, clubId), saisons:[], bilan:{g:0, n:0, p:0}};
  club.tactique = TACTIQUE_DEFAUT(); club.compo = compoAuto(M, clubId);
  M.manager.postes = [{club:clubId, debut:M.saison}];
  if (C() && C().apresChoixClub) C().apresChoixClub(M, clubId);   // v85 : centre de formation
  const o = M.manager.objectif;
  message(M, `Bienvenue à ${club.nom}`, `Le président vous confie l'équipe pour la saison ${M.saison}-${String(M.saison + 1).slice(2)}. Objectif : ${o.txt.toLowerCase()}. Il juge les résultats chaque semaine.`, 'pres');
  message(M, 'Le mot du staff', 'La composition proposée est la meilleure selon les notes au poste. Réglez les consignes dans Tactique avant le premier match ; l\'attrapeur est réglé pour ne prendre le vif d\'or que si ça fait gagner.', 'staff');
  return M;
}

/* ---------- Fin de saison ---------- */
function finDeSaison(M){
  const lab = `${M.saison}-${String(M.saison + 1).slice(2)}`;
  const champs = {}; for (const L of Object.values(M.ligues)) champs[L.id] = classement(M, L.id)[0].id;
  const ancien = M.calendrier.some(s => s.tour), sixn = ancien ? classement(M, 'sixn')[0].id : null, ldn = M.ldn && M.ldn.saison === M.saison ? M.ldn.vainqueur : null;
  const h = {saison:lab, champions:champs, sixn, ldn};   // v106 : vainqueur de la Ligue des nations (l'été de la saison), Six Emblèmes pour une saison d'avant
  if (clubJoueur(M)){
    const C = classement(M, M.clubs[M.manager.club].ligue), pos = C.findIndex(x => x.id === M.manager.club) + 1, o = M.manager.objectif;
    h.manager = {club:M.manager.club, pos, objectif:o.vise};
    const ecart = o.vise - pos;
    M.manager.rep = Math.round(borne(M.manager.rep + ecart * 1.2 + (pos === 1 ? 8 : 0), 1, 100) * 10) / 10;
    M.manager.confiance = Math.round(borne(M.manager.confiance + ecart * 4, 0, 100));
    M.manager.saisons.push({saison:lab, club:M.manager.club, pos});
    message(M, `Bilan de la saison ${lab}`, `${M.clubs[M.manager.club].nom} termine ${pos}${pos === 1 ? 'er' : 'e'} (objectif : ${o.vise === 1 ? 'titre' : 'top ' + o.vise}). Champions : ${Object.values(M.ligues).map(L => M.clubs[champs[L.id]].nom).join(', ')}.${sixn ? ` ${D.TOURNOI.court} : ${D.NATIONS[sixn].nom}.` : ''}${ldn ? ` ${D.LDN.nom} : ${D.NATIONS[ldn].nom}.` : ''}`, 'pres');
  }
  M.histo.push(h);
  if (root.QMG && root.QMG.eteBancs) root.QMG.eteBancs(M);   // v159 : bilan des entraîneurs de l'ordinateur, valse des bancs
}
/* passage à la saison suivante (appelé par l'écran après le bilan) */
function saisonSuivante(M){
  const r = hasard(melange(M.graine, 'saison', M.saison));
  if (C()) C().avantSaison(M, r);                     // v84 : primes, contrats qui se terminent, agents libres
  /* vieillissement, retraites et jeunes (v84 : la progression se fait chaque semaine à l'entraînement) */
  for (const club of Object.values(M.clubs)){
    for (const id of club.effectif.slice()){
      const j = M.joueurs[id];
      if (!C()) progresser(j, r);
      j.age++;
      const part = j.age >= 37 || r() < (RETRAITE[j.age] || 0);   // v113 : retraites étalées (avant : 8 % dès 32 ans, 35 % dès 34, tous à 36)
      if (part){
        club.effectif = club.effectif.filter(x => x !== id); delete M.joueurs[id];
        const lvl = EQ.niveauMin + (club.rep - 40) / 45 * (EQ.niveauMax - EQ.niveauMin) + r.gauss() * 0.9;
        const n = creerJoueur(r, r.pondere(D.ORIGINES[club.nat]), j.poste, lvl - 2.8 + 0.3 * (C() ? C().niv(club, 'formation') - 2 : 0), AGE_JEUNE(r), 'j' + (M.prochainId++));   // v113 : −2,8 (avant −1,5 : avec sa marge de potentiel, chaque génération dépassait la précédente)
        n.club = club.id; n.num = j.num; M.joueurs[n.id] = n; club.effectif.push(n.id); if (C()) C().nouveauJoueur(M, n, club);
        if (clubJoueur(M) === club.id) message(M, `${nomJ(j)} prend sa retraite`, `${j.age} ans. Le centre de formation fait monter ${nomJ(n)} (${n.age} ans, ${D.POSTES[n.poste].nom.toLowerCase()}).`, 'staff');
      }
    }
    for (const id of club.effectif){ const j = M.joueurs[id]; j.saison = {m:0, b:0, v:0, cog:0, arr:0, notes:0}; j.cj = 0; j.fat = 0; j.charge = 0; j.forme = 6; j.moral = 60; if (j.bless) j.bless.jours = Math.max(0, j.bless.jours - 60) || null; if (j.bless && !j.bless.jours) j.bless = null; }
    if (clubJoueur(M) !== club.id){ club.compo = compoAuto(M, club.id); club.tactique = tactiqueIA(r); if (root.QMG && root.QMG.construirePlans) root.QMG.construirePlans(M, club); }   // v152 : plans selon le nouvel effectif
    else verifierCompo(M, club.id);
  }
  M.saison++; M.semaine = 0;
  basculer(M, r);                                     // v106 : une partie d'avant v106 passe à 4 championnats
  M.calendrier = calendrierSaison(M, r);
  remettreClassements(M);
  if (C()) C().apresSaison(M, r);
  if (M.annonceBascule){ message(M, ...M.annonceBascule, 'club'); delete M.annonceBascule; }   // v106
  if (clubJoueur(M)){ M.manager.objectif = objectif(M, M.manager.club); M.manager.bilan = {g:0, n:0, p:0};
    message(M, `Saison ${M.saison}-${String(M.saison + 1).slice(2)}`, `Nouvel objectif du président : ${M.manager.objectif.txt.toLowerCase()}.`, 'pres'); }
}
/* v106 : partie à 3 championnats (B&I, France, Italie) → 4 championnats de 16 (britannique, latin, scandinave, d'Europe centrale).
   Les 20 clubs de D.RESERVE sortent du jeu (sauf le club du joueur, remplacé par le club gardé le plus faible de sa nation) ;
   leurs meilleurs joueurs de 30 ans au plus deviennent agents libres, les autres quittent le jeu. Les clubs sortis restent
   lisibles dans M.reserve (nom, couleurs) pour le palmarès. Les 36 nouveaux clubs arrivent avec leur effectif. */
function basculer(M, r){
  if (!M.ligues.fr && !M.ligues.it) return false;
  const moiC = clubJoueur(M), sortis = new Set(D.RESERVE.filter(id => M.clubs[id]));
  if (moiC && sortis.has(moiC)){
    const nat = M.clubs[moiC].nat, rempl = Object.values(M.clubs).filter(c => c.nat === nat && !sortis.has(c.id) && c.id !== moiC).sort((a, b) => a.rep - b.rep)[0];
    sortis.delete(moiC); if (rempl) sortis.add(rempl.id);
  }
  delete M.ligues.fr; delete M.ligues.it;
  for (const L of D.LIGUES) if (!M.ligues[L.id]) M.ligues[L.id] = {id:L.id, nom:L.nom, court:L.court, clubs:[]};
  M.reserve = M.reserve || {};
  const libres = [];
  for (const id of sortis){
    const c = M.clubs[id];
    M.reserve[id] = {id, nom:c.nom, ville:c.ville, nat:c.nat, rep:c.rep, couleurs:c.couleurs, sigle:c.sigle, stade:c.stade, ligue:null, effectif:[], reserve:true};
    const L = c.effectif.map(x => M.joueurs[x]).filter(Boolean).sort((a, b) => note20(b, b.poste) - note20(a, a.poste));
    L.forEach((j, k) => { if (k < 3 && j.age <= 30){ j.club = null; j.contrat = null; delete j.pret; libres.push(j.id); } else delete M.joueurs[j.id]; });
    delete M.clubs[id];
  }
  for (const c of Object.values(M.clubs)) if (c.ligue === 'fr' || c.ligue === 'it') c.ligue = 'la';
  const nouveaux = [];
  for (const def of D.CLUBS) if (!M.clubs[def[0]] && !M.reserve[def[0]] && M.ligues[def[4]]) nouveaux.push(creerClub(M, r, def));
  for (const L of Object.values(M.ligues)) L.clubs = Object.values(M.clubs).filter(c => c.ligue === L.id).map(c => c.id);
  for (const c of nouveaux){ if (C()) C().nouveauClub(M, r, c); for (const id of c.effectif) if (C()) C().nouveauJoueur(M, M.joueurs[id], c); }
  if (M.libres) M.libres.push(...libres);
  /* références vers les clubs sortis et les joueurs partis */
  const ok = id => !!M.clubs[id], okJ = id => !!M.joueurs[id];
  if (M.offres) M.offres = M.offres.filter(o => okJ(o.j) && (!o.de || ok(o.de)) && (!o.club || ok(o.club)));
  if (M.libres) M.libres = M.libres.filter(okJ);
  for (const c of Object.values(M.clubs)){ c.effectif = c.effectif.filter(okJ); if (c.suivi) c.suivi = c.suivi.filter(okJ); if (c.aVendre) c.aVendre = c.aVendre.filter(okJ); }
  nommer(M);   // v114
  if (C() && C().apresBascule) C().apresBascule(M, sortis);
  if (M.manager) M.annonceBascule = ['Quatre championnats', `La fédération européenne réorganise le Quidditch : ${D.LIGUES.map(L => M.ligues[L.id].nom).join(', ')}, 16 clubs chacun. ${Object.values(M.reserve).filter(c => sortis.has(c.id)).map(c => c.nom).join(', ')} quittent l'élite (une deuxième division les attend). La Ligue des Anneaux prend les 4 premiers de chaque championnat. Le Tournoi des Six Emblèmes laisse la place à trois trêves internationales (matchs amicaux tirés au sort) et, un été sur deux, à la Ligue des nations : 19 sélections, des groupes puis l'élimination directe.`, ];   // publié après les messages de la nouvelle saison (en tête de la boîte)
  return true;
}
function progresser(j, r){
  const [p1, p2] = D.PICS[j.poste], ca = note20(j, j.poste), pot = j.cache.pot, pro = j.cache.pro / 10;
  let delta;
  if (j.age < p1) delta = borne((pot - ca) * (0.25 + 0.03 * (p1 - j.age)) * pro, 0, 2.5);
  else if (j.age <= p2) delta = borne((pot - ca) * 0.15 * pro, -0.2, 0.8);
  else delta = -(0.3 + 0.18 * (j.age - p2));
  const phys = new Set(['vit', 'acc', 'end', 'agi', 'ref']);
  j.a = j.a.map((v, i) => {
    let d = delta + r.gauss() * 0.5;
    if (delta < 0 && !phys.has(ATT[i])) d = delta * 0.35 + r.gauss() * 0.4;
    if (delta < 0 && D.ATTRS[i][2] === 'Mental') d = 0.2 + r.gauss() * 0.4;
    return Math.round(borne(v + d, 1, 20));
  });
  if (j.poste === 'G') j.g = j.g.map(v => Math.round(borne(v + delta + r.gauss() * 0.5, 1, 20)));
}

/* ---------- Sauvegarde ---------- */
/* attributs écrits en lettres (1 → A … 20 → T) : la sauvegarde pèse trois fois moins */
const enLettres = L => String.fromCharCode(...L.map(v => 64 + v));
const deLettres = t => [...t].map(c => c.charCodeAt(0) - 64);
function serialiser(M){
  return JSON.stringify(M, (k, v) => (k === 'a' || k === 'g') && Array.isArray(v) && v.length && typeof v[0] === 'number' ? enLettres(v) : v);
}
function charger(txt){
  const M = typeof txt === 'string' ? JSON.parse(txt) : txt;
  if (!M || !M.clubs || !M.joueurs || !M.calendrier || !(M.v >= 1 && M.v <= VERSION)) throw new Error('Fichier QM27 illisible ou d\'une version plus récente');
  for (const j of Object.values(M.joueurs)){ if (typeof j.a === 'string') j.a = deLettres(j.a); if (typeof j.g === 'string') j.g = deLettres(j.g); }
  const v0 = M.v;
  if (M.v < VERSION && C()) C().migrer(M);           // v84 : une partie du lot 1 reçoit contrats, staff, finances
  for (const c of Object.values(M.clubs)){ completerTactique(c.tactique); if (c.compo && c.compo.pen === undefined) rolesAuto(M, c.compo, true); }   // v89 : dispositions, tireur de penalty
  if (M.sel && M.sel.tactique) completerTactique(M.sel.tactique);
  if (v0 < 5 && M.manager) message(M, 'Nouveautés de QM27 : match et tactique', 'Tactique : deux dispositions, avec et sans le souafle, et une zone d\'attaque à choisir sur le terrain (chaque défense craint une zone). Tireur de penalty désigné, manies des joueurs (fiche joueur), buts attendus. En direct : le terrain vu du dessus, les autres scores à la radio, les conseils de l\'adjoint, des résumés qui suivent l\'enjeu et une ambiance sonore (Réglages).', 'club');
  if (v0 < 8) for (const j of Object.values(M.joueurs)){ if (!j.cache) continue; const ca = note20(j, j.poste); j.cache.pot = Math.round(Math.max(ca, Math.min(j.cache.pot, ca + margeMax(j.age))) * 10) / 10; }   // v94
  M.v = VERSION;
  if (M.ligues.fr && M.manager && !M.avisV106){ M.avisV106 = 1; message(M, 'À la fin de cette saison : quatre championnats', `Cette saison se termine comme prévu (Ligue de France, Ligue d'Italie, Tournoi des Six Emblèmes). À l'intersaison, le Quidditch européen passe à quatre championnats de 16 clubs : ${D.LIGUES.map(L => L.nom).join(', ')}. Vingt clubs français et italiens quittent l'élite${M.manager.club && D.RESERVE.includes(M.manager.club) ? ' (ton club reste : un autre club de ton pays sort à sa place)' : ''}, les Six Emblèmes laissent la place aux trêves internationales et à la ${D.LDN.nom}.`, 'club'); }   // v106
  if (!Object.values(M.joueurs).some(j => j.inter)) convoquer(M);   // v91 : convocations de la semaine en cours
  for (const [id, [vieux, neuf]] of Object.entries(COULEURS_REVUES)){ const c = M.clubs[id] || (M.reserve || {})[id]; if (c && c.couleurs && c.couleurs.join() === vieux.join()) c.couleurs = neuf.slice(); }   // v130
  return nommer(M);
}
/* v130 : couleurs de club revues ; une partie en cours les reçoit si le club avait encore les anciennes */
const COULEURS_REVUES = {firenze:[['#4a148c', '#b388ff'], ['#4b2c6f', '#cdbfe0']]};

/* v114 : noms des clubs et des ligues dans la langue choisie (réglage de l'appareil, posé par l'écran : QM.langueNoms). Appliqué à la création
   d'un monde, au chargement d'une partie et après la réorganisation des ligues ; les anciens messages gardent leurs noms d'origine. */
let LANGUE_NOMS = 'local';
function nommer(M, mode){
  mode = mode || LANGUE_NOMS; if (!M) return M;
  const k = mode === 'en' ? 0 : mode === 'fr' ? 1 : -1;
  for (const c of [...Object.values(M.clubs || {}), ...Object.values(M.reserve || {})]){
    const def = D.CLUBS.find(x => x[0] === c.id); if (!def) continue;
    c.nom = k >= 0 && D.NOMS_CLUBS[c.id] ? D.NOMS_CLUBS[c.id][k] : def[1];
    c.ville = k >= 0 && D.VILLES_LANGUES[c.id] && D.VILLES_LANGUES[c.id][k] || def[2];
  }
  const nomL = (L, cible) => { const n = L.noms && L.noms[mode] || L.noms && L.noms.local; if (n){ cible.nom = n[0]; cible.court = n[1]; } };
  for (const L of D.LIGUES) if (M.ligues && M.ligues[L.id]) nomL(L, M.ligues[L.id]);
  for (const L of Object.values(D.LIGUES_ANCIENNES)) nomL(L, L);
  return M;
}
function langueNoms(mode){ LANGUE_NOMS = ['local', 'en', 'fr'].includes(mode) ? mode : 'local'; nommer({}, LANGUE_NOMS); return LANGUE_NOMS; }
/* v106 : une ligue du palmarès, même disparue (Ligue de France, Ligue d'Italie) */
const ligueDe = (M, id) => M.ligues[id] || D.LIGUES_ANCIENNES[id] || {id, nom:String(id), court:String(id), clubs:[]};
root.QM = {arbitrePour, nommer, langueNoms, AGE_JEUNE, ligueDe, roundRobin, creerClub, basculer, chargeFacteur, plancherFatigue, matchsDuJoueur, convoquer, convoques, finirMatchDuJoueur, natJoueur, VERSION, clubJoueur, campJoueur, tactiqueIA, apresMatchManager, finDeSaison, hasard, melange, note, note20, noteBrute, POIDS_NOTE, POIDS_NOTE_G, partNote, meilleurPoste, at, ga, ATT, IDX, POIDS, rolesAuto, roleAuto, creerJoueur, borne, dispo, nouveauMonde, choisirClub, compoAuto, verifierCompo, titulaires, TACTIQUE_DEFAUT,
           semaine, matchDuJoueur, preparerMatch, simulerMatch, creerMatch, equipeClub, selection, pas, jusquAuBout, tempsMort, remplacer, resume, notesMatch,
           terminerSemaine, saisonSuivante, classement, objectif, serialiser, charger, nomJ, message, attente,
           manies, aManie, maniesPour, sansDe, CONTRE, completerTactique,
           rendement:(X, eq, id) => f(X, eq, id), scoreRole, execRole, qualiteRole, refRole, typique, badge, synergiesDe, antiSynergiesDe, leviers, optimiserRoles, enjeuDe, forces, maitriseDe, maitriseEquipe, equipesPour, grainePour, campPour, meteoPour, probas, lv, multFatigue, poidsTireurs, qualiteTir, nbRole, role:(X, eq, id) => role(X, eq, id),   // v96 : analyse tactique (qm27-tactique.js)
           meteoPrevue:(M, m, S) => meteoPour(hasard(grainePour(M, m)), S.date)};   // v88 : boule de cristal
})(typeof window !== 'undefined' ? window : globalThis);
