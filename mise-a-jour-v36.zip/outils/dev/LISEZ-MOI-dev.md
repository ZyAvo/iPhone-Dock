# Mon Écran — notes techniques (pour reprendre le projet dans une nouvelle conversation)

État au 30/10/2026 : **lot v35**, phase 1 terminée.

## Organisation du dépôt
- Pages (racine) : `index.html` (accueil), `actus.html`, `sport.html`, `ecarts.html` (écarts de cotes), `invest.html`, `videos.html`, `etat.html`, `cachee.html` (coffre), `synchro.js` (synchro chiffrée), `sw.js` (service worker).
- `config/` : réglages écrits par la tâche **Configuration** depuis `configuration.xlsx` (racine). Les pages chargent `config/config.js` (`window.MON_ECRAN_CONFIG`) et lisent leurs réglages avec `CFG('module.clé', valeur par défaut)` ; sans config, elles gardent leurs valeurs intégrées. Les expressions régulières sont stockées `{re, flags}`.
- `outils/` : scripts des tâches GitHub (`*-data.mjs`, `tv-tri.mjs`, `etat.mjs`), lecteur de config commun `config-lire.mjs`, convertisseur du classeur `configuration.py`.
- Branche `donnees` : données publiées par les tâches (`donnees/…`). Branche `synchro` : fichier chiffré de synchronisation.
- `.github/workflows/` : tâches (ne peuvent pas être modifiées par une tâche : à déposer à la main).

## Livraison d'une mise à jour
1. Partir du dernier lot (dépôt cloné), modifier, vérifier : `python3 outils/dev/checkjs.py .` (syntaxe JS de toutes les pages et scripts).
2. Empaqueter : `python3 outils/dev/empaqueter.py <dossier> vNN mise-a-jour-vNN.zip` (marque chaque fichier de son empreinte, écrit `lot.json`, ignore `config/`).
3. Yoann dépose le zip à la racine ; la tâche **Mise à jour** l'installe et relance les tâches concernées. Les fichiers `.github/workflows` sont à déposer à la main.
4. Ne jamais livrer `config/` ni `configuration.xlsx` dans un zip : ce sont les réglages de l'utilisateur.

## Classeur de configuration (`outils/dev/classeur/`)
- `modele.py` (+ `cat_sport.py`, `cat_actus.py`, `cat_autres.py`, `tuto.py`) : contenu des onglets ; chaque ligne a un identifiant fixe (colonne A cachée) et sa définition technique (colonne « Technique » cachée, JSON).
- Nouvelle version du classeur en reprenant les choix de l'ancien : `python3 construire.py reference.json nouveau.xlsx ancien.xlsx` (puis incrémenter `VERSION_CLASSEUR` et le journal dans `tuto.py`).
- `extraire.mjs <dossier>` : réglages d'origine écrits dans les pages → `reference.json`. `comparer.py <dossier config>` : vérification « zéro différence » entre la config produite et ces réglages.
- Choix personnels (favoris, abonnements vidéo, villes météo) : **pas** dans le classeur ; réglés dans l'appli et partagés par la partie « prefs » de la synchro.

## Phase 2 (prévue)
1. Lot technique : `config/modifs.json` écrit par l'appli (identifiant → Oui/Non, ajouts) et reporté par la tâche dans `configuration.xlsx` (le classeur reste la référence) ; `config/catalogue.json` (tout le catalogue et son état) pour proposer les choix dans l'appli.
2. Écrans à cocher : médias d'actus, chaînes YouTube, compétitions, marchés/fonds.
3. Activer/désactiver pages et widgets (déjà dans `config/accueil.json`, pas encore appliqué).
4. Éditeur de l'accueil (applis, dossiers, bandeau ; 3 liens par appli déjà dans `config/applis.json`).
Anticiper des applis dédiées : `noyau.js` commun (config, stockage, synchro, lien selon l'appareil), écrans sans astuce propre à Safari, fonctions propres à l'iPhone web isolées.

## Tests
Playwright + Chromium : servir une copie du dépôt avec `donnees/` (branche `donnees`) et `config/`, comparer le texte rendu des pages avant/après, capturer en 390×844 clair/sombre.
